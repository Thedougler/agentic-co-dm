---
type: sequence
status: pending
publish: false
aliases: []
summary: "If the party keeps the borrowed Grung POV alive through five zones, he reaches Karath; if they fail the critical check, he dies. Same cut either way."
created: "2026-08-10"
updated: "2026-08-14"
tags: [survival, maritime, horror]
tier: supporting
prep_depth: planned
pass: "If the party keeps the POV alive through five zones, he reaches Karath."
fail: "If they fail a critical check on or after step 3, the POV dies in the water."
steps: 5
parent_situation: "[[aruhe-hungry-isle]]"
encounter: ""
session_number: 9
sequence_number: 1
used_by: ["[[e09-run-guide-open-strait]]"]
npcs: []
locations: ["[[aruhe|Aruhe]]", "[[karath|Karath]]"]
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/draft-content/references/sequence.md"
uid: 4ba9dbd7-bf3d-4b63-a353-bda2620d196c
---

# Session 09, Sequence 1: Cold Open on Aruhe

## Pass

If the party keeps the POV alive through five zones, his hands find [[karath|Karath]].

## Fail

If they fail a critical check on or after step 3, the water takes him.

## Steps

Six people start: the POV guardsman, the scarred-lip [[grung|Grung]], the younger silent Grung, the long-hair, the branded one (iron mark on the left shoulder), the bearded old captive. One warped predator per zone. Each predator turns at the terrain that gives the next its footing. A group that stalls in a zone gives the current creature more time.

A success on a zone check clears the guardsman; the person at stake dies. A critical success saves that person too. Failure is the same death, closer. Critical failure on or after step 3 is Fail — end the open.

![[moment-01-cold-open-aruhe-narration-open]]

### Step 1 — Goat at the tideline

![[moment-01-cold-open-aruhe-narration-goat]]

> [!check] Goat at the tideline
>
> | Check | DC | Failure | Pass |
> |---|---|---|---|
> | Group Dexterity | bands | CF 5-24: the ram takes the old man; the charge turns at the tideline. F 25-49: the ram takes him in the open. | S 50-84: the ram takes him; the party is already in the water. CS 85+: the old man lives. |

### Step 2 — Elk on the reef

![[moment-01-cold-open-aruhe-narration-elk]]

> [!check] Elk on the reef
>
> | Check | DC | Failure | Pass |
> |---|---|---|---|
> | Group Athletics | bands | CF 5-29: the long-hair and the branded one go under; the party is knocked sideways. F 30-54: both die; the party is past the elk. | S 55-79: both die behind the party; they cross the color line. CS 80+: both live. |

### Step 3 — Crocodile at the color line

![[moment-01-cold-open-aruhe-narration-crocodile]]

> [!check] Crocodile at the color line
>
> | Check | DC | Failure | Pass |
> |---|---|---|---|
> | Group Athletics | bands | CF 5-34: the crocodile takes the scarred-lip Grung; the undertow takes the POV. **Fail.** F 35-59: the crocodile takes him; the party kicks past. | S 60-84: the crocodile takes him; the party clears the boundary. CS 85+: both Grung clear it. |

### Step 4 — Octopus in the kelp

![[moment-01-cold-open-aruhe-narration-octopus]]

> [!check] Octopus in the kelp
>
> | Check | DC | Failure | Pass |
> |---|---|---|---|
> | Group Stealth | bands | CF 5-49: the younger Grung goes under; a second arm takes the POV. **Fail.** F 50-74: he goes under; the POV cuts free. | S 75-89: he goes under; the POV surfaces alone. CS 90+: he lives. |

### Step 5 — Shark in the last half-mile

![[moment-01-cold-open-aruhe-narration-shark]]

> [!check] Shark in the last half-mile
>
> | Check | DC | Failure | Pass |
> |---|---|---|---|
> | Group Constitution | bands | CF 5-59: the POV's legs stop; the fin closes. **Fail.** F 60-84: he hauls out on [[karath\|Karath]] spent. | S 85-94: he reaches Karath with the fin still cutting. CS 95+: he reaches it with breath in reserve. |

## Connections

- [[aruhe-hungry-isle|Aruhe's Hungry Isle]]
- [[aruhe|Aruhe]]
- [[karath|Karath]]
