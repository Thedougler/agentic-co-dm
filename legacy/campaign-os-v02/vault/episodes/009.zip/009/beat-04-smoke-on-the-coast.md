---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - intrigue
summary: Smoke rises off the coast and barques run north empty. House Renzetti is moving value out of Sparhold before the duel decides who keeps it.
engagement: optional
thread: "[[house-kailani|Sparhold's Challenge]]"
trigger: The crew holds a south or southwest heading with the coast in view, any daylight leg approaching Sparhold.
if_ignored: Whatever Renzetti shipped out this stretch of coast is already north and out of reach by the time the duel concludes. The crew can't press the settlement to recover it, and the settlement's own account of the duel's spoils comes up short with no one able to say why.
ripens: ""
reusable: false
beat_number: 4
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: []
locations:
  - "[[campaigns/shattered-sea/locations/midchain/sparhold|Sparhold]]"
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 4: Smoke on the Coast

> [!read-aloud]
> Grey smoke stands off the shoreline in three thin columns, leaning north with the wind and never thickening into a single plume. Between you and it, two barques run the opposite way you'd expect. Hulls high and holds empty, they cut north with the coast at their beam. Their deck lines sit slack, holds bare of the cut timber that should ride below the waterline or stack at the rails. A signal flag snaps at the near one's mast, answered five heartbeats later from the second, and both hold their heading without slowing for a hail.

## What Happens

House Renzetti is clearing value out of Sparhold ahead of the duel's outcome, not waiting to see whether Ottavia's champion wins the settlement's rule. Barques carrying cut timber bound for the Crown's contract should be running loaded south. Instead they run empty north, already unloaded and headed back for another load before anyone can account for what left.

Loaded barques normally run south to the settlement. These two run north and empty, a signal that cargo already moved out ahead of them, with no record of it.

**If they dig:** the smoke traces to a timber yard flying no visible banner, but its cut boundary and stacking pattern match [[house-renzetti|House Renzetti]]'s known holdings. The fires are burning off what Renzetti couldn't ship in time, not battle damage or accident. It's a house securing its own stock against the chance it loses tomorrow's rule and everything under it.

## Checks

> [!check] Investigation — Trace the Yard
> **DC 13.** The crew closes enough to read the yard's cut lines and stacking marks against known Renzetti holdings.
> **Success:** the burn pattern reads as deliberate salvage, not sabotage, and the yard checks out as Renzetti's.
> **Failure:** the yard's ownership stays unclear. The crew notes only that someone is moving fast before a deadline.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[house-kailani|Sparhold's Challenge]]
- [[house-renzetti|House Renzetti]]
