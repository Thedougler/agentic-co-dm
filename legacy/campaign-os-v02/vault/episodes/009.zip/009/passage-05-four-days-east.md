---
type: passage
status: pending
publish: false
aliases: ["Four Days East", "East Crossing"]
created: "2026-08-11"
updated: "2026-08-13"
tags: [maritime, travel, exploration]
summary: "Four days east across the Central Strait to The Drowned Maw, where compasses lie from day two and the chair's base holds Rook's charts."
method: ship
distance: Far
duration: "four days"
from_moment: "[[fork-01-the-heading-choice]]"
destination: "The Drowned Maw"
reconverges_at:
beats:
  - "[[beat-03-waveservant-wreckage]]"
  - "[[beat-06-strange-pennant]]"
  - "[[beat-08-the-chemical-story]]"
  - "[[beat-09-the-depot]]"
  - "[[beat-10-the-squall]]"
conditions: "Compasses fail from day two; final two days on sun angle and star fixes over unmapped water"
passage_number: 5
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: ["[[old-faas|Old Faas]]", "[[geoffrey-draves|Geoffrey Draves]]", "[[thunk|Thunk]]", "[[sem-holst|Sem Holst]]", "[[master-kyzil|Master Kyzil]]"]
locations: ["[[central-strait|The Central Strait]]", "[[the-drowned-maw|The Drowned Maw]]"]
campaigns: [Shattered Sea]
owner_skill: "vault/episodes/.claude/skills/draft-passage/SKILL.md"
---

# Session 9, Passage 5: Four Days East

## Departure Cost

Shortest crossing in table time, but the crew trades certainty for speed. Compasses begin lying from day two, and the final two days run on sun angle and star fixes over water the Crown has never formally charted.

## The Crossing

The *[[uncertainty|Uncertainty]]* runs four days east across the [[central-strait|Central Strait]], the binnacle compass swinging five degrees east and correcting and swinging again from first light of the second day. The final two days run on sun angle and star fixes, the needle no reliable guide at all. Recovered charts from the base of the [[fleet-commanders-chair|Fleet Commander's Chair]] carry [[barnaby-rook|Rook]]'s depth soundings for this exact water, and grant advantage on the leg's navigation roll. The heading ends at [[the-drowned-maw|the Maw]]'s western shelf, where the water changes colour in a single stroke of the hull.

## Roles

[[old-faas|Old Faas]] wants the leg's stations named before the needle goes, and he stands at the tiller waiting for an answer instead of filling the silence. This leg runs the Maw tier. Any of the five stations left uncalled makes no roll, and the crossing takes that station's failure side unanswered.

![[ship-operations#Stations Underway]]

Recovered charts grant advantage on the leg's [[intelligence|Intelligence]] ([[navigators-tools|Navigator's Tools]]) roll. Roll the five dice twice with Rook's soundings in hand and keep the better total.

## Group Check

> [!check] Group Navigator's Tools — Four Days on a Lying Needle
> **Critical Failure (5-25):** the star fixes disagree with the sun, and both disagree with the log. The ship raises the trench sixty miles north of the shelf, with 1d4 days to work back south, and dawn shows the same bare horizon it showed at dusk.
>
> **Failure (26-49):** a day goes to quartering for the colour change. The water turns flat and bottomless under the hull after dark, with no landmark to place the ship against until first light.
>
> **Success (50-74):** the seabirds turn back at noon on the third day, and the shelf comes up on the fourth where Old Faas said it would.
>
> **Critical Success (75+):** a day shaved. The shelf edge comes up in full afternoon light with soundings running, and dusk sits far enough off to put eyes on whatever follows.

## Beat Menu

| # | Beat file | Type | Trigger |
|---|---|---|---|
| 3 | [[beat-03-waveservant-wreckage\|Waveservant Wreckage]] | optional | Open horizon in daylight, a stripped hull drifts into view |
| 6 | [[beat-06-strange-pennant]] | optional | Another sail crosses the heading under an unknown pennant |
| 8 | [[beat-08-the-chemical-story]] | optional | The crew checks or restocks the reagent stores after two days at sea |
| 9 | [[beat-09-the-depot]] | optional | Orange hull on the starboard bow, second day before the needle starts lying |
| 10 | [[beat-10-the-squall]] | optional | Northwest horizon darkens, the chop turning quartering against the current |

## Landmark

Where pale green water turns to bottomless black in one stroke of the hull: the colour change marks the shelf edge dropping away, and the [[the-drowned-maw|Maw]]'s unmapped water begins beneath the keel.

## Toll

Two days of lying compasses strip certainty from every bearing. The Maw tier runs on this leg and applies to all checks. The crew reaches the shelf knowing where the needle pointed, not where the ship actually went.

## Arrival Changed

The crew reaches unmapped water knowing what rides in the hold and what Kyzil warned about on the third morning, with or without Rook's charts in hand.

## Next

[[the-drowned-maw|The Drowned Maw]], when the crossing ends.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[the-drowned-maw|The Drowned Maw]]
