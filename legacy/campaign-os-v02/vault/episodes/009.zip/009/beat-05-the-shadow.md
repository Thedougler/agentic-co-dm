---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - intrigue
summary: An Aarakocra shadows the ship for a full watch, cataloguing it against the Countless's Fate Spinner sweep, then peels off on its own terms.
engagement: optional
thread: "[[the-countless|The Long Sight Hunt]]"
trigger: a crew member on deck or aloft spots the Aarakocra holding altitude off the ship's line
if_ignored: the Aarakocra completes its watch uninterrupted and reports the sighting back to its hire, one more uncorrelated data point in the Countless's broadened sweep
ripens: ""
reusable: true
beat_number: 5
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: []
locations: []
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 5: The Shadow

> [!read-aloud]
> A shape holds high off the port quarter, wings barely working, matching the ship's speed without closing the distance. It has kept that same bearing since first light, holding through two changes of heading and two full watch bells. Then, with no signal anyone on deck can name, it banks east and climbs until the gray swallows it.

## What Happens

The Countless broadened its hunt for anyone still carrying a [[fate-spinner|Fate Spinner]] into a standing sweep, paying disposable watchers to canvas shipping lanes instead of pursuing known targets. This [[aarakocra|Aarakocra]] is one sweep in that pattern, sent to hold a ship's line long enough to read who's aboard, then report back regardless of what it finds. Its presence here says nothing yet about whether the crew is a real target. It says the sweep has widened enough to reach them.

The Aarakocra held one bearing across a full watch and broke away on its own initiative, unforced by pursuit or startle, the clear signature of a deliberate scouting run.

**If they dig:** Aarakocra don't hold a ship's line for a full watch without cause. Asking around a port or working a Nature/Investigation check on the sighting turns up word that someone's been paying for watches just like this one lately, disposable, uncorrelated, and thorough.

## Checks

> [!check] Perception — Spotting the Watcher
> DC 15, passive works if anyone's above deck or aloft during the watch.
> **Success:** the crew clocks the Aarakocra early enough to watch its full pattern: the fixed bearing and the deliberate departure.
> **Failure:** only the tail end registers, a shape banking away at altitude with no context for how long it had been there.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[the-countless|The Countless]]
