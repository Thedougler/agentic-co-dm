---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-14
tags:
  - maritime
  - intrigue
summary: A skiff crosses from The Velvet Noose with a sealed set of priced, timed terms.
engagement: optional
thread: "[[the-velvet-noose|The Velvet Noose]]"
trigger: the crew crosses into a stretch of the Central Strait The Velvet Noose actively claims
if_ignored: the Noose reads silence as refusal. The skiff returns with the same terms and a fifteen-minute deadline; if that expires too, the full boarding in [[encounter-velvet-noose-intercept|Velvet Noose Intercept]] begins with no further parley
ripens: ""
reusable: false
beat_number: 11
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs:
  - "[[mave-sorn|Mave Sorn]]"
locations: []
encounter: "[[encounter-velvet-noose-intercept|Velvet Noose Intercept]]"
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 11: Velvet Terms

## Narration

> [!read-aloud]
> A dark sail holds the horizon while a skiff peels away from it, low in the water and moving on matched oars. It raises no flag or hail.
>
> The boat comes alongside the *[[uncertainty|Uncertainty]]*'s port rail, where a single sailor braces a lacquered tube against the hull and clips its line to the rope ladder. Wax seals the tube's cap. A neat label carries the ship's name, already dry despite the spray.
>
> The sailor raises one hand, then backs water. Behind him, the distant sail holds position and watches through the glare. The tube knocks twice against the planking.
>
> What do you do?

## What Happens

The [[the-velvet-noose|Velvet Noose]] works this stretch of the [[central-strait|Central Strait]], and she does not open her gunports before she has offered terms. A skiff crosses from her position and delivers a sealed tube. She runs this same opening move on every vessel that crosses her water: business conducted before either side fires. The tube's terms name the *[[uncertainty|Uncertainty]]* directly.

**The signal is concrete:** the terms name the ship specifically and set a fixed deadline. They ask for a declared manifest of the forward hold and one hour of boarding for inspection, with safe passage and a Captain-sealed letter of transit offered in return.

**If they dig:** the terms don't ask about cargo value or coin. They ask pointedly about "any irregularity" carried in the forward hold, phrasing closer to a Crown dispatch than a ransom note. Whatever she's really after, it isn't the manifest.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[the-velvet-noose|The Velvet Noose]]
- [[mave-sorn|Mave Sorn]]
- [[encounter-velvet-noose-intercept|Velvet Noose Intercept]]
- [[velvet-noose-takes-the-lane|The Velvet Noose Takes the Lane]]
