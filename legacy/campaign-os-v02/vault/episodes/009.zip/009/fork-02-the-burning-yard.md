---
type: fork
status: pending
publish: false
aliases: ["Fork 2: The Burning Yard", "s09 fork 2"]
summary: "Four hours north of Sparhold a Kailani timber yard burns, and whichever single use the crew makes of those four hours destroys the other two."
created: "2026-08-10"
updated: "2026-08-12"
tags: [maritime, midchain]
tier: supporting
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
fork_number: 2
world_date: "1495 DR"
from_moment: "[[moment-07-timber-yard-fire]]"
reconverges_at: ""
campaigns: [Shattered Sea]
owner_skill: "vault/episodes/.claude/skills/draft-fork/SKILL.md"
uid: 6f2c5da5-259b-48e0-b3b0-3c155c9d7ecc
---

# Session 09, Fork 2: The Burning Yard

## The Situation

The davits hold one boat for one job. Four hours north of [[sparhold|Sparhold]]'s boom chain, sap along the cut boundary is the only proof tying the [[grung-clans|Grung]] raiders to [[house-kailani|House Kailani]]'s timber-quarrel account, surviving only as long as fire and tide leave it lying, and the raiders' trail dries as a second stack catches within the hour. Barques running north reach the chain first, reporting a blue-black hull off the burning yard: the *[[uncertainty|Uncertainty]]* arrives behind a reputation either way. Saving it reads as a Kailani hull to [[house-renzetti|House Renzetti]], whose challenge bell has stood nine days rung, while holding course reads as the one that watched.

## Paths

| Path | Condition | Type | Next |
|---|---|---|---|
| Up the cut | If they go up the cut | exclusive | [[moment-15-the-green-cut-trail\|The Green Cut Trail]] |
| The fire and the cutters | If they stay and work the fire | exclusive | [[moment-16-the-kailani-smack\|The Kailani Smack]] |
| Past the smoke | If they hold their course for the chain | exclusive | [[moment-08-sparhold-arrival\|Sparhold Arrival]] |

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[moment-07-timber-yard-fire|The Timber Yard Fire]], the moment that lands here
