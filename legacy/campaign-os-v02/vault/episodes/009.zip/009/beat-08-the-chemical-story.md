---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - intrigue
summary: The ship's reagent stores show a depletion pattern that reads as a transmutation process to anyone who knows the trade.
engagement: optional
thread: "[[simone-tabarnack|Finish Becoming Gold]]"
trigger: the crew checks or restocks the ship's stores after two or more days at sea
if_ignored: the quartermaster notes the shortfall in the next manifest and flags it as pilferage, and the crew starts eyeing one another for a thief
ripens: ""
reusable: false
beat_number: 8
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs:
  - "[[simone-tabarnack|Simone Tabarnack]]"
locations: []
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 8: The Chemical Story

> [!read-aloud]
> Under the pitch and bilge sits a thin mineral sting, sharp at the back of the throat, coming off the reagent crates near the aft bulkhead. Whoever counts the stores finds three jars of powdered orpiment scraped near-empty, a sealed tin of quicksilver salts cracked and lighter than it should be, and a coil of copper wire gone missing entirely. The loss manifest carries none of it, and the weather and the crossing account for none of it either.

## What Happens

Something aboard the [[uncertainty|Uncertainty]] is consuming specific alchemical reagents faster than spoilage or ordinary use accounts for: the exact ingredients a transmutation stabilizer draws on. The draw is small and steady, a little more each day the ship is out: the trace of a process running quietly somewhere in the hold, day after day.

The depletion pattern is specific, not random. Orpiment, quicksilver salts, and copper wire together are the working set for a metal-transmutation stabilizer, and any alchemist or [[ranger|Ranger]] with a nose for the trade reads them that way, not as general spoilage.

Matching the pattern against what's known of [[grung|Grung]] physiology and gold-caste transformation lore points to someone with access to the hold dosing a stabilizing tincture aboard, on a schedule.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[simone-tabarnack|Simone Tabarnack]]
