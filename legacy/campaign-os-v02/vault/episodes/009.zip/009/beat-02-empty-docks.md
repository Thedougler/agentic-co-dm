---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - intrigue
summary: A Midchain fishing village sits nearly empty, boats tied up and its wage board tripled overnight. The fighting-age levy has reached it too.
engagement: optional
thread: "[[grung-clans|The Fighting-Age Levy]]"
trigger: The crew passes within sight of a Midchain coastal settlement between ports
if_ignored: The crew never confirms the pattern reached this far. The next port they visit shows the same missing-persons desk two segments further along, and they arrive with no warning at all
ripens: ""
reusable: true
beat_number: 2
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: []
locations: []
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 2: Empty Docks

> [!read-aloud]
> The village comes up on the port rail, a dozen shingled roofs and a stone jetty, small enough to carry no name on most charts. No smoke rises from more than two chimneys. A line of fishing boats sits tied gunwale to gunwale at the jetty, sails furled, none out on the water despite a clean morning for it. The only sound carrying across the water is a loose halyard slapping a mast, over and over. On the jetty's shore end, a board stands propped against a barrel, fresh paint still bright: wages for crew, tripled, and not a single name signed on beneath.

## What Happens

The Grung raiding pattern that emptied [[calveno|Calveno]] has reached this [[midchain|Midchain]] settlement. Raiders took every fighting-age man in a single night, working the same patrol-gap timing and the same restraint that left women, children, and elders untouched. What remains is a village that cannot crew its own boats or work its own nets, offering wages no local economy could otherwise support, because there is nobody left to bid the price back down. The settlement runs on inertia now, not recovery.

**The signal:** the rate. It sits three times what Calveno paid before its own raid, and every boat at the jetty rides fully rigged and unmanned, a village with the means to fish and nobody able-bodied enough left to do it.

**If they dig:** the story. Anyone willing to talk (a child watching the jetty, an elder mending net alone) confirms it happened one night roughly two months back. Raiders took every man of fighting age by morning, left no ransom demand, and gave no warning before or since. The timing matches the same watch-gap pattern that hit Calveno, though nobody here has connected it to a wider cause. They believe they were simply unlucky.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[grung-clans|The Fighting-Age Levy]]
