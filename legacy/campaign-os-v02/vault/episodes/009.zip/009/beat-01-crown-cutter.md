---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - intrigue
summary: A Crown cutter runs a grid search pattern across the horizon, cataloguing hulls. The Dravosi Crown's fleet-wide search enters its systematic phase.
engagement: optional
thread: "[[dravosi-crown|HCS Surety, Crown Search]]"
trigger: The crew is at sea with open horizon visibility (a passage leg, a becalmed stretch, any daylight crossing).
if_ignored: The cutter logs their hull unremarked. A later Crown checkpoint or boarding treats them as an unverified vessel instead of a known one, with the heavier scrutiny that carries.
ripens: ""
reusable: true
beat_number: 1
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: []
locations: []
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 1: Crown Cutter

> [!read-aloud]
> A sail breaks the horizon to the north, squared and pale against high cloud. It does not pass on. Through one long watch it holds a line, then swings hard about, laying track after track across open water like a plow squaring a field. Twice a bell rings from her deck, one pause, then once more, timing each turn to the second. The spyglass rests within reach on your own rail. Through it the hull resolves: low, grey, a Crown ensign stiff at the stern, and a line of figures along her side marking each passing hull onto a slate before the next sweep begins.

## What Happens

A Dravosi Crown cutter works a fixed grid across the strait, turning at timed intervals instead of holding a patrol lane. She is not hunting the crew specifically. She is logging every hull that crosses her view. The fleet is early in a coordinated search, methodical instead of aggressive.

The tight, timed turns of the search pattern, unlike a patrol's wandering course, signal a census over pursuit.

**If they dig:** a spyglass look or a hail reveals the crew working from a checklist, cross-referencing hull silhouettes against a list the officer keeps below decks. The grid covers the whole strait; every ship in these waters gets logged, the [[saltwright|Saltwright]] included.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[dravosi-crown|Dravosi Crown]]
