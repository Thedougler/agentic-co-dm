---
type: moment
status: pending
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime, intrigue]
summary: "Sparhold's boom chain closes behind the hull as a Kailani Guard records name, business, and the yard, then sets the bond before the last link comes up."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 8
world_date: "1495 DR"
reached_from: ["[[fork-02-the-burning-yard]]", "[[moment-15-the-green-cut-trail]]", "[[moment-16-the-kailani-smack]]"]
fork_depth: 2
engagement: required
terminal: true
npcs: ["[[nico-renzetti]]", "[[rangi-kailani]]"]
monsters: []
statblocks: []
locations: ["[[campaigns/shattered-sea/locations/midchain/sparhold]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: 15ba50fc-4b01-4e11-9a5a-00ce2b5497a9
---

# Session 09, Moment 8: Sparhold Arrival

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-08-sparhold-arrival-narration-open]]

![[moment-08-sparhold-arrival-dialogue-guard]]

## What Happens

The chain opens once and closes behind them. The Guard serves [[house-kailani|House Kailani]], holding their claim against [[house-renzetti|House Renzetti]]'s unanswered bell. Every hull is a faction vote, and she records, not hunts. What she writes decides who calls on them tonight.

Whichever house holds Sparhold when the crew wants an answer about the timber, the raids, or a berth gives it, and the entry she takes now is what that house reads first.

Nine days rung and unsettled, [[nico-renzetti|Nico Renzetti]] against [[rangi-kailani|Rangi Kailani]] in the ring outside the watch hall, to the death, for the rule of the place and the cut it lives on. The crier's slate carries the posting, and the crowd around it carries the wagers.

She has served this harbour, not the Crown, so the hull reads as a trader to her. The [[dravosi-crown|Dravosi Crown]] writ she names is [[commander-gideon-ault|Commander Ault]]'s, and Kailani honours his search warrants for the goodwill it buys.

Women, boys, and old men work these docks, exactly the pattern [[jean-claude-tabarnack|Jean-Claude]] has been reading up the coast since [[corrigans-rest|Corrigan's Rest]] ([[grung-clans|the Fighting-Age Levy]]). Sparhold calls it the raids and blames the boundary.

The barques that ran north out of the smoke carried word of a blue-black hull standing off a burning Kailani yard, and it reached the walls before the crew did. Crew that went ashore at the yard, in any number: the harbour officer holds a description of them working somebody else's fire, and reads it as help or as arson depending on what the deck says now. Crew that held their course past the smoke: the harbour officer holds a description of a hull that watched a Kailani yard burn and did not stop.

If the deck stalls, she writes *unstated* in the business column, sets the bond at double, and the entry follows the crew into every conversation Sparhold gives them.

## What they want

**The ask:** direct. She wants a name, a stated business, and a bond taken on the weapons before the chain is back at height, and she will hold the boat alongside until she has all three.

## Checks

> [!check] Deception (DC 14) — What Goes in the Ledger
> **Success:** entry reads as a coastal trader on [[midchain|Midchain]] business; standard bond; the crew's yard account is the first Sparhold hears.
>
> **Failure:** she logs Crown lines under fresh paint; a search party boards at the morning bell with Kailani's blessing.
>
> **Fail by 5+:** she calls the second smack over before the crew leave the water; the search is tonight, tincture crate still in the hold.

> [!mechanic] Martial Law, Until the Duel Settles
> No weapon leaves the vessel without a bond posted against it at the landing table, and no more than four crew stand outside the hull at any hour. Breaking either is not a fine: the watch takes the offender to the ring's holding cell until the bell settles the succession.

## Next

The chain sits at height. The ledger holds whatever the deck gave it. Inside the walls, two men in a ring will settle who owns every door, and the last link is still coming up out of the water.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[fork-02-the-burning-yard|The Burning Yard]], the fork that lands here
- [[sparhold|Sparhold]]
- [[house-kailani|House Kailani]]
- [[house-renzetti|House Renzetti]]
- [[nico-renzetti|Nico Renzetti]]
- [[rangi-kailani|Rangi Kailani]]
