---
type: passage
status: pending
publish: false
aliases: ["Seven Days Southwest", "Southwest Crossing"]
created: "2026-08-11"
updated: "2026-08-13"
tags: [maritime, travel]
summary: "Seven days southwest on the Blue Lane to Kalowe, through the Crown's widest search net with no friendly port, where the crate sweats, the chair waits, and Kyzil breaks his own rule."
method: ship
distance: "Very Far"
duration: "seven days"
from_moment: "[[fork-01-the-heading-choice]]"
destination: "Kalowe"
reconverges_at:
beats:
  - "[[beat-03-waveservant-wreckage]]"
  - "[[beat-04-smoke-on-the-coast]]"
  - "[[beat-06-strange-pennant]]"
  - "[[beat-08-the-chemical-story]]"
  - "[[beat-09-the-depot]]"
  - "[[beat-10-the-squall]]"
conditions: "Blue Lane, deepest and fastest water in the Central Strait; Crown search net at widest"
passage_number: 4
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: ["[[old-faas|Old Faas]]", "[[geoffrey-draves|Geoffrey Draves]]", "[[sem-holst|Sem Holst]]", "[[thunk|Thunk]]", "[[master-kyzil|Master Kyzil]]"]
locations: ["[[calveno|Calveno]]", "[[central-strait-crossing|The Central Strait Crossing]]", "[[kalowe|Kalowe]]"]
campaigns: [Shattered Sea]
owner_skill: "vault/episodes/.claude/skills/draft-passage/SKILL.md"
---

# Session 9, Passage 4: Seven Days Southwest

## Departure Cost

Seven days through the Crown's widest search net, no friendly port between [[calveno|Calveno]] and [[kalowe|Kalowe]]. The hull still wears the wrong paint under a thin coat, and the dry dock there is the only place in the [[midchain|Midchain]] that takes any paying hull and asks nothing about the one before it.

## The Crossing

The *[[uncertainty|Uncertainty]]* takes the Blue Lane, the deepest and fastest water in the [[central-strait|Central Strait]], seven days of open sea with no coast and no break in it. Northeast wind holds steady from the first watch. Off the starboard bow, a line of broken masts marks the wreckage crowning [[sandtable-shoal|Sandtable Shoal]], close enough this watch to angle toward for a look or leave dead astern. The heading ends at [[kalowe|Kalowe]]'s dry dock, still inside the Crown's widest search net the whole way.

## Roles

[[old-faas|Old Faas]] licks his pencil stub and looks the length of the deck. He wants every station named and written against a name before the first night watch, and he will stand on the deck until he has them. Defaults: [[delmar-fisk|Delmar]] Captain at the tiller, [[crissdalynn-khinriss|Crissdalynn]] Lookout, [[catarina-davirelli|Catarina]] Navigator, [[perrin-black-jaw|Perrin]] Quartermaster, [[jean-claude-tabarnack|Jean-Claude]] Bosun, or whatever swap the table argues its way into, one station per PC and no station twice. The Blue Lane runs as charted water and the wind has held steady, so the leg rolls at the charted tier.

![[ship-operations#Stations Underway]]

## Group Check

> [!check] Group Survival — Seven Days on the Blue Lane
> **Critical Failure (5-25):** the Lane's fastest water slips off the bow overnight, growing the crossing by a day that lands after a second hull has already taken up the chase.
>
> **Failure (26-49):** a cask of water sours and the rigging shows its age, so the first hard sail-order of the night comes late and half-answered.
>
> **Success (50-74):** stores hold and the crossing runs true, with the crew sighting whatever the horizon brings before it sights them.
>
> **Critical Success (75+):** the crossing gives up a full day, and the crew meets every following beat at the range and posture of its own choosing.

![[central-strait-crossing#Hazards]]

## Beat Menu

| # | Beat file | Type | Trigger |
|---|---|---|---|
| 3 | [[beat-03-waveservant-wreckage\|Waveservant Wreckage]] | optional | Open horizon in daylight, a stripped hull drifts into view |
| 4 | [[beat-04-smoke-on-the-coast]] | optional | Smoke rises off the coast and empty barques run north |
| 6 | [[beat-06-strange-pennant]] | optional | Another sail crosses the heading under an unknown pennant |
| 8 | [[beat-08-the-chemical-story]] | optional | The crew checks or restocks the reagent stores after two days at sea |
| 9 | [[beat-09-the-depot]] | optional | Orange hull appears mid-crossing, unmistakable at a mile on the Blue Lane |
| 10 | [[beat-10-the-squall]] | optional | Northwest horizon darkens mid-crossing, squall shelf moving faster than cloud |

## Landmark

Off the starboard bow, the [[sandtable-shoal|Sandtable Shoal]] wreckage shows against the glare as a line of broken masts close enough to angle toward for a look or leave dead astern.

## Toll

Seven days of open water while the Crown search closes. Every day without port lets the net tighten. The leg ends at [[kalowe|Kalowe]] with whatever the hull has declared and whatever it hasn't.

## Arrival Changed

The crew reaches [[kalowe|Kalowe]]'s dry dock knowing what rides in the hold, what sits in the aft cabin, and what the sky warned about on the second evening. They dock with the same hull questions they left [[calveno|Calveno]] with, plus answers the crossing forced on them.

## Next

[[kalowe|Kalowe]], when the crossing ends.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[kalowe|Kalowe]]
