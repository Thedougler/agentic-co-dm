---
type: fork
status: pending
publish: false
aliases: []
summary: "The crew names one of four bearings out of the Central Strait, and that heading becomes the night's whole voyage."
created: "2026-08-10"
updated: "2026-08-13"
tags: [maritime, exploration, travel]
tier: supporting
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
fork_number: 1
world_date: "1495 DR"
from_moment: "[[moment-03-the-heading-choice]]"
reconverges_at: ""
campaigns: [Shattered Sea]
owner_skill: "vault/episodes/.claude/skills/draft-fork/SKILL.md"
uid: 0c049970-9dbb-409f-a210-53a293180b02
---

# Session 09, Fork 1: The Heading Choice

## The Situation

- West: [[high-eyrie|the High Eyrie]]'s bare stair, rising straight from open water.
- South: [[sparhold|Sparhold]]'s boom chain, timber yard burning at its edge.
- Southwest: [[kalowe|Kalowe]]'s dry dock, takes any hull, asks nothing.
- East to the Maw: the bottomless trench under [[the-drowned-maw|The Drowned Maw]], four days, compasses lying from day two.
- [[passage-01-crossing-to-fathomrush|East to Fathomrush]]: [[fathomrush|Fathomrush]]'s iron rigs on the [[midchain-east|eastern Midchain]], six days past the shelf on a lying needle.

## Paths

| Path | Condition | Type | Next |
|---|---|---|---|
| West to [[high-eyrie\|the High Eyrie]], three days against the Scatter Current | If they head west | exclusive | [[passage-02-three-days-west]] |
| South to [[sparhold\|Sparhold]], four days down a busier chain | If they head south | exclusive | [[passage-03-four-days-south]] |
| Southwest to [[kalowe\|Kalowe]], seven days through the widest part of the Crown search, no friendly port to duck into | If they head southwest | exclusive | [[passage-04-seven-days-southwest]] |
| East to [[the-drowned-maw\|The Drowned Maw]], open-ended, with compass drift from two days out | If they name the Maw | exclusive | [[passage-05-four-days-east]] |
| East to Fathomrush, six days past the Maw's shelf on a lying needle | If they name Fathomrush | exclusive | [[Six Days East]] |

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[moment-03-the-heading-choice|The Heading Choice]], the moment that lands here
