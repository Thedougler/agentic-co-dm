---
type: passage
status: pending
publish: false
aliases: ["Six Days East", "East to Fathomrush"]
created: "2026-08-11"
updated: "2026-08-13"
tags: [maritime, travel, exploration]
summary: "Six days east past The Drowned Maw to Fathomrush on the eastern Midchain, where two companies fly their colours from opposite headlands and a wall of carved names sits between them."
method: ship
distance: Far
duration: "six days"
from_moment: "[[fork-01-the-heading-choice]]"
destination: "Fathomrush"
reconverges_at:
beats:
  - "[[beat-03-waveservant-wreckage]]"
  - "[[beat-06-strange-pennant]]"
  - "[[beat-08-the-chemical-story]]"
  - "[[beat-09-the-depot]]"
  - "[[beat-10-the-squall]]"
  - "[[beat-12-storm-debris]]"
conditions: "Compasses fail from day two; final four days run on sun angle and star fixes past the Maw's shelf edge"
passage_number: 1
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: ["[[old-faas|Old Faas]]", "[[geoffrey-draves|Geoffrey Draves]]", "[[thunk|Thunk]]", "[[sem-holst|Sem Holst]]", "[[master-kyzil|Master Kyzil]]"]
locations: ["[[central-strait|The Central Strait]]", "[[the-drowned-maw|The Drowned Maw]]", "[[fathomrush|Fathomrush]]"]
campaigns: [Shattered Sea]
owner_skill: "vault/episodes/.claude/skills/draft-passage/SKILL.md"
---

# Session 9, Passage 1: Six Days East

## Departure Cost

Choosing [[fathomrush|Fathomrush]] means pointing past the [[the-drowned-maw|Maw]]'s lying compasses and leaving every other heading for later. Whatever [[sparhold|Sparhold]]'s duel settles, whatever [[high-eyrie|the Eyrie]] reveals, those clocks run while the ship runs east. The [[dravosi-crown|Crown]] search runs thin past the shelf, not absent, and there is no friendly port between the Maw and Fathomrush to duck into if the six days go wrong.

## The Crossing

The *[[uncertainty|Uncertainty]]* runs six days east: four across the [[central-strait|Central Strait]], the binnacle compass swinging from first light of the second day, then two more east along [[the-drowned-maw|the Maw]]'s shelf edge where the water has already changed colour and the trench drops away beneath the keel with nothing to anchor to. [[barnaby-rook|Rook]]'s charts cover the Maw approach. His soundings never reached the eastern shelf run beyond. The final two days run on sun angle and stars alone. [[fathomrush|Fathomrush]]'s iron scaffolding comes visible before the harbour mouth opens on the sixth morning, two sets of company colours flying from opposite headlands, close enough across the water to read each other's rigging. Which company's dock the *Uncertainty* ties up at first is a decision both companies are already watching for.

## Roles

[[old-faas|Old Faas]] wants the leg's stations named before the needle goes, and he stands at the tiller waiting for an answer instead of filling the silence. This leg runs the Maw tier. Any of the five stations left uncalled makes no roll, and the crossing takes that station's failure side unanswered.

![[ship-operations#Stations Underway]]

Rook's charts cover only the Maw approach, not the eastern shelf run. No advantage applies on this leg. The final two days are beyond any chart aboard.

## Group Check

> [!check] Group Navigator's Tools — Six Days on a Lying Needle
> **Critical Failure (5-25):** star fixes disagree past the shelf edge and the sun runs behind cloud on day five. The ship raises Fathomrush's western headland three miles north of the harbour mouth, half a day's working south through water nobody has sounded, and both companies see the approach.
>
> **Failure (26-49):** four days of compass drift and two of dead reckoning leave the final approach uncertain. The *Uncertainty* raises Fathomrush on schedule but on the wrong angle, straight into the gap between the two company docks, with every hand on both piers watching the awkward entry.
>
> **Success (50-74):** the shelf's colour change comes up where it should, and the eastern run holds on sun angle alone. Fathomrush rises off the port quarter on the sixth morning with the harbour mouth open and readable.
>
> **Critical Success (75+):** the two extra days beyond the Maw run clean on a steady southerly. The ship raises Fathomrush in early afternoon light with enough time to read both company docks before committing to one.

## Beat Menu

| # | Beat file | Type | Trigger |
|---|---|---|---|
| 3 | [[beat-03-waveservant-wreckage\|Waveservant Wreckage]] | optional | Open horizon in daylight, a stripped hull drifts into view |
| 6 | [[beat-06-strange-pennant]] | optional | Another sail crosses the heading under an unknown pennant |
| 8 | [[beat-08-the-chemical-story]] | optional | The crew checks or restocks the reagent stores after two days at sea |
| 9 | [[beat-09-the-depot]] | optional | The orange hull of the [[nimmik-vollask\|Nimmik Vollask]] appears broad on the starboard bow during the [[central-strait-crossing\|Central Strait crossing]] |
| 10 | [[beat-10-the-squall]] | optional | A squall shelf closes from the northwest mid-crossing, the chop turning quartering against the Scatter Current |
| 12 | [[beat-12-storm-debris]] | optional | The ship crosses the western drift or the crew searches open water for missing [[grung\|Grung]] ships |

## Landmark

[[fathomrush|Fathomrush]]'s wall, a low plank barrier between the two company piers, sixty feet across the harbour mouth, not owned by either dock. A hundred carved names nobody has painted over. Both companies are watching which side the *Uncertainty* ties up at before anyone has asked her business.

## Toll

The Maw tier applies to all checks on this leg. Six days of lying compasses and the final two on nothing but star fixes strip certainty from every bearing made since day two. The crew reaches [[fathomrush|Fathomrush]] without a chart for the approach and without having seen what the eastern shelf looked like before the harbour swallowed it.

## Arrival Changed

The crew reaches [[fathomrush|Fathomrush]] having already chosen a dock, with whatever they learned on the crossing (what's in the hold, what [[master-kyzil|Kyzil]] said on the third morning, who intercepted them on the Strait) carried into a harbour where two companies are watching opposite sides of the same silence about whose trials are real.

## Next

[[fathomrush|Fathomrush]], when the crossing ends.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[fathomrush|Fathomrush]]
- [[the-drowned-maw|The Drowned Maw]]
