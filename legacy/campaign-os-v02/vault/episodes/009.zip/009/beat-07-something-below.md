---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - horror
summary: Something massive and rhythmic passes beneath the hull in deep water off Sparhold, then vanishes.
engagement: optional
thread: "[[the-tangle|The Below]]"
trigger: the ship crosses a calm stretch of deep water near Sparhold, with no other action drawing focus
if_ignored: harbor gossip the next tide names a fishing skiff working that same stretch of water, its nets torn through and half its catch gone, the crew unable to say what took it
reusable: true
beat_number: 7
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 7: Something Below

> [!read-aloud]
> The deck swallows the sound of your boots, not silence, a change in it. A low thrum climbs up through the timbers, steady as a heartbeat, three beats and a pause, three beats and a pause. Over the rail the water goes the color of wet slate, darker by degrees, and a shape too broad to be current slides under the hull and vanishes. The thrum fades with it. The sea closes back over whatever passed, flat and unbothered, like nothing happened at all.

## What Happens

Something large and deliberate moves beneath the ship in deep water off [[sparhold|Sparhold]], a piece of the ongoing construction of the Below moving through in transit, dead weight under tow or a hull section driven at depth, kept well clear of any harbor watch. The crew feels the pass but never sees a cause.

The signal is a fixed rhythm through the deck timbers, three beats and a pause repeating, steady as machinery, unlike any current or a living thing swimming below.

**If they dig:** the rail shows an empty sea, nothing breaking the surface where the shape passed. Sparhold's own depth chart says nothing should move at that size this far out from the shelf, the water too deep for a whale to work and too far from any known reef or wreck to explain a natural giant.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|parent Run Guide]]
</content>
