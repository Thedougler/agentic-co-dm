---
type: moment
status: pending
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime, midchain, intrigue]
summary: "After the second stack dies, Petro Amaru beaches a Kailani smack, walks the cut line first, then demands the crew's account of the fire."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 16
world_date: "1495 DR"
reached_from: ["[[fork-02-the-burning-yard]]"]
fork_depth: 1
engagement: required
terminal: false
npcs: ["[[petro-amaru]]", "[[ussa]]"]
monsters: []
statblocks: []
locations: ["[[sparhold]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: a9e8e967-20f5-49e6-9ad6-962c0637f6da
---

# Session 09, Moment 16: The Kailani Smack

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-16-the-kailani-smack-narration-open]]

![[moment-16-the-kailani-smack-dialogue-amaru]]

## What Happens

This is [[petro-amaru|Petro Amaru]]'s yard, cut off a boundary he has been moving for years. He needs one clean account of the fire under his name before the ebb refloats both hulls and takes him south. An outside hand set the blaze. The cut-line matches the harbour books, paid in coin or [[house-kailani|House Kailani]] goodwill at the boom chain. Sap from the forest side says the [[grung-clans|Grung]] hit this yard alone, which only holds if the line moved. [[sparhold|Sparhold]]'s harbour authority checks his figures closely.

Twenty-odd cutters watched strangers work the buckets. The arson version of the blue-black hull costs Amaru more than he can pay. The version he can afford names the crew as witnesses to a [[house-renzetti|House Renzetti]] hand at a Kailani yard. He pays well in goodwill for that page.

[[ussa|Ussa]] chalked this boundary last season and knows the real line to the tree. Amaru's coin buys her kin out of the clans' hatchery camps, so she keeps her seat and says nothing. Six yard-security axes stay in the boat unless someone draws steel on the shingle.

Barques already running north carry a description of the hull ahead of him. If the crew gives him nothing, he writes "strangers, no names," pays two cutters to remember the morning that way, and refloats south before the page reaches the watch hall. He means to be useful to whichever house wins the chain. If they stall, Amaru still walks the boundary rows in front of the whole bucket line. Ussa answers one question about the chalk marks if asked out of his hearing. His ledger sits open on a stump the moment cutters bring him water.

## What they want

**The ask:** direct. He wants the crew's own account of the fire dictated onto his page, and anything picked up off the boundary rows handed over with it, priced aloud in Kailani goodwill at the boom chain.

## Checks

> [!check] Insight (DC 13, watching him write; seeing both open ledger faces auto-succeeds) — Reading the Foreman
> **Success:** pencil is fastest on boundary rows and cut width; it stops when the fire comes up.
>
> **Success by 5+:** the page in his hand is not the page he showed the yard foreman; the two carry different figures for the same rows.
>
> **Failure:** no tell beyond hurry to leave before the ebb.

> [!mechanic] The Smack Stands Off
> Steel drawn anywhere on the shingle and the smack shoves off the beach at once, six axes aboard her and Amaru with them. Sparhold then hears the morning as a boarding: the watch hall marks the crew's hull hostile, and the landing table refuses a bond on their weapons until the bell settles.

## Next

[[moment-08-sparhold-arrival|Sparhold Arrival]], as soon as the ebb lifts both hulls off the shingle and the run south puts the crew at the boom chain behind Amaru's page and the barques both.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[fork-02-the-burning-yard|The Burning Yard]], the fork that lands here
- [[petro-amaru|Petro Amaru]]
- [[ussa|Ussa]]
- [[house-kailani|House Kailani]]
- [[house-renzetti|House Renzetti]]
- [[sparhold|Sparhold]]
