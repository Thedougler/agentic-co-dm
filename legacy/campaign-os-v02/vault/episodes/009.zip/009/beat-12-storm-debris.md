---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - intrigue
summary: A western drift line carries fresh Grung wreckage, captive lashings, and a chart scrap marked for Karath past the Uncertainty on any crossing near the Central Strait.
engagement: optional
thread: "[[grung-clans|The Fighting-Age Levy]]"
trigger: The Uncertainty crosses or approaches the Central Strait's western drift line, or searches open water for evidence of Nona's missing people.
if_ignored: The current carries the identifiable pieces beyond the shipping lanes; later reports preserve the storm and lost hulls, but not the chart mark that points toward Karath and Aruhe.
ripens: ""
reusable: true
beat_number: 12
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: []
locations:
  - "[[campaigns/shattered-sea/locations/central-strait|Central Strait]]"
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 12: Storm Debris

> [!read-aloud]
> The swell is wrong before the wreckage comes into view. Flat lines of driftwood comb into windrows on a current with nothing else to catch.
>
> Splintered outrigger struts ride the swell. A keel section rolls belly up beside them, resin-sealed joinery bright where the storm tore it open. Knotted wrist cords trail from one thwart, cut through at both ends.
>
> A waxed chart case knocks against the planking. Its lid hangs open, and one salt-stiff scrap remains inside, marked with a southbound line toward [[karath|Karath]] and a black cross beside [[aruhe|Aruhe]]. The current is already pulling the case under the next line of wreckage.
>
> What do you do?

## What Happens

The storm that struck the [[grung|Grung]] raiding fleet carrying captives south from [[calveno|Calveno]] hit the crossing days ago. The western drift has separated this evidence from the wreck sites and can carry it across any nearby route without moving [[aruhe|Aruhe]] itself.

The wreckage carries unmistakable Grung construction, narrow raiding-hull lines, resin-sealed joinery, cut captive lashings, and a surviving chart mark. It proves that at least one part of the fleet broke south of the charted line. It does not prove who survived or require the crew to follow it.

**If they dig:** the drift direction places the break east of the main southbound lane. The chart scrap connects [[karath|Karath]] to Aruhe, while Human-cut lashings and a child-sized sandal caught under the thwart show captives rode these hulls.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[grung-clans|The Fighting-Age Levy]]
- [[aruhe-wreck|The Aruhe Wreck]]
- [[aruhe-hungry-isle|Aruhe's Hungry Isle]]
