---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - intrigue
summary: Fresh wreckage drifts into view, holds emptied and crew gone, a Waveservant tribute seal nailed to the mast, the Dead Lady taking boats as payment against Delmar's unpaid Pearl debt.
engagement: optional
thread: "[[waveservants|The Tribute Rampage]]"
trigger: The crew is at sea with open horizon visibility (a passage leg, a becalmed stretch, any daylight crossing).
if_ignored: Another empty hull turns up on a charted lane, holds emptied and crew gone the same way. Dock rumor about the red ship reaches a port well before any official report does.
ripens: ""
reusable: true
beat_number: 3
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: []
locations: []
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 3: Waveservant Wreckage

> [!read-aloud]
> A hull rides low off the beam, sails furled and still, turning slow with the swell like something already dead in the water. The rail comes into range first: split in two places, splinters bright and unweathered. Then the deck, swept bare down to the boards, hatches thrown open on empty holds. Nailed to what's left of the mast, a lead disc the size of a fist, stamped with a wave-and-anchor mark, green at the edges from fresh salt.

## What Happens

The Dead Lady takes vessels whole and strips them bare: crew and cargo gone over the side, hull left adrift as the only trace. This one crossed the crew's own heading recently enough that the wreck is still fresh, days old at most. [[umberlee|Umberlee]] is not collecting general shrine tribute here; she is taking hulls one at a time against Delmar Fisk's unpaid debt for the [[pearl-of-souls|Pearl of Souls]], and this is the newest receipt.

**The signal:** the seal. Nailed to the mast, stamped fresh instead of offered, it marks a toll taken from this hull.

**If they dig:** the seal's stamped mark doesn't match any ledger this ship's own crew would have kept. Whatever debt it pays down belongs to someone else's account, not this hull's.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[waveservants|Waveservants]]
- [[dead-lady|Dead Lady]]
- [[delmar-fisk|Delmar Fisk]]
