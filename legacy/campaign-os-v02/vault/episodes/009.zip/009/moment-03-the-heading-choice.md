---
type: moment
status: pending
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime, travel]
summary: "Geoffrey Draves lays five bearings out on the new chart table, gives each equal weight, and leaves the heading to the crew."
tier: supporting
edit_pass: 0
used_by: ["[[e09-run-guide-open-strait]]"]
session_number: 9
moment_number: 3
world_date: "1495 DR"
reached_from: []
fork_depth: 0
engagement: required
terminal: false
npcs: ["[[geoffrey-draves]]"]
monsters: []
statblocks: []
locations: ["[[central-strait]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: d24a9c0a-9705-4628-b84f-442127d27232
---

# Session 09, Moment 3: The Heading Choice

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-03-the-heading-choice-narration-open]]

## What Happens

[[rupert-knighton|Rupert Knighton]]'s Crown search still works the [[central-strait|Strait]] for the *[[uncertainty|Uncertainty]]* under her old name. It closes on its own clock. [[kalowe|Kalowe]]'s seven days run through the widest stretch of that search, with no friendly port if a Knight closes.

## What they want

**The ask:** direct. [[geoffrey-draves|Geoffrey Draves]] wants a bearing named so he can lay the course.

## Connections

- [[geoffrey-draves|Geoffrey Draves]]
