---
type: session
subtype: run-guide
status: pending
publish: false
aliases: ["Session 09 Run Guide", "The Open Strait", "s09 run guide", "e09-run-guide"]
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, exploration, travel]
summary: "Opening stretch for session 09: Aruhe cold open, La Vasca, heading choice, then Exit to a destination walk."
tier: core
edit_pass: 0
session_number: 9
session_date: 2026-08-16
world_date: "1495 DR"
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/run-guide.md"
uid: ba833d89-677b-458a-832e-cd77d7afe6df
---

# The Open Strait

## Last Time

![[e09-run-guide-narration-last-time]]

## Prep

[[aruhe|Aruhe]] first, then [[calveno-la-vasca|La Vasca]], then a heading. Stay on this page until they name a bearing.

Reminders: players are a Grung on Aruhe until the cut. Five courses are equal. Shared water can still surface [[velvet-noose-takes-the-lane|Velvet Noose]].

## 1 — Aruhe

Players are a [[grung|Grung]] on [[aruhe|Aruhe]]. Walk the Sequence top to bottom.

![[sequence-01-cold-open-aruhe#Pass]]

![[sequence-01-cold-open-aruhe#Fail]]

![[sequence-01-cold-open-aruhe#Steps]]

> [!check] Aruhe
>
> | Check | DC | Failure | Pass |
> |---|---|---|---|
> | Survival | 14 | the beach is the beach | the island takes what is taken — [[aruhe-hungry-isle]] |
> | Investigation | 13 | wreckage | [[grung]] joinery, a [[vethka\|Vethka]] scrap marked for [[karath]] |

Hard cut on hands finding [[karath|Karath]], or on the water closing.

## 2 — La Vasca

Hard cut to the dock. The *[[uncertainty|Uncertainty]]* casts off.

![[moment-02-la-vasca-departure-narration-open]]

> [!check] La Vasca
>
> | Check | DC | Failure | Pass |
> |---|---|---|---|
> | Perception | 13 | dock noise | the tribute basin is waiting — [[old-faas]] |
> | Insight | 14 | he is in a hurry | he wants the sea debt named before the arch — [[umberlee]] |
> | Investigation | 15 | a new chair | [[fleet-commanders-chair]] — hollow base, [[barnaby-rook]]'s Maw soundings |
> | Sleight of Hand | 15 | someone is watching | a locker or tool from the refit claimed |
> | Persuasion | 14 | he holds the coin out again | tribute paid or owing is named |

![[moment-02-la-vasca-departure#What Happens]]

![[moment-02-la-vasca-departure#What they want]]

They linger aboard → [[uncertainty-refit-tour-run-guide|Refit Tour]], then return here when the mooring lines go slack.

## 3 — Heading

[[geoffrey-draves|Geoffrey]] pins five equal courses.

![[moment-03-the-heading-choice-narration-open]]

> [!check] Heading
>
> | Check | DC | Failure | Pass |
> |---|---|---|---|
> | Insight | 13 | five equal courses | he wants a useful station aboard — [[geoffrey-draves]] |
> | History | 14 | names on a chart | [[rupert-knighton]] still searches [[central-strait\|the Strait]] for the old name |
> | Survival | 13 | open water | west, south, and east change how long they sit on that search |

![[moment-03-the-heading-choice#What Happens]]

![[moment-03-the-heading-choice#What they want]]

Once they name a bearing, leave this page through Exit.

## Side-tracks

- [[uncertainty-refit-tour-run-guide|Refit Tour]] — curiosity stays aboard
- [[aruhe-hungry-isle-run-guide|Aruhe]] — they turn east or follow wreckage after the cut
- [[velvet-noose-takes-the-lane-run-guide|Velvet Noose]] — claimed water on any bearing
- [[fork-01-the-heading-choice|Bearings]] — five courses on one page if the table wants the chart
- On destination walks: [[moment-05-high-eyrie-approach]] · [[moment-07-timber-yard-fire]] · [[fork-02-the-burning-yard]] · [[moment-15-the-green-cut-trail]] · [[moment-08-sparhold-arrival]] · [[moment-16-the-kailani-smack]] · [[moment-14-vestra-water]] · [[moment-13-the-shelfworks]] · [[moment-10-the-brigantine]] · [[moment-11-the-dead-lady-finds-them]]

## Exit

- west → [[high-eyries-storm-door-run-guide|High Eyrie]]
- south → [[sparholds-burning-challenge-run-guide|Sparhold]]
- southwest → [[kalowes-frozen-council-run-guide|Kalowe]]
- east → [[drowned-maws-open-shelf-run-guide|the Maw]]
- far east → [[fathomrushs-split-harbor-run-guide|Fathomrush]]
