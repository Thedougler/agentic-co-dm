---
type: moment
status: pending
publish: false
aliases: ["Session 09 Moment 5", "High Eyrie Approach"]
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime, exploration]
summary: "Rain and a Maw-surge ring close the High Eyrie: no dock, a stair twenty feet up, and Kyzil writes the arriving ship then warns Crissdalynn to hide the dreidel."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 5
world_date: "1495 DR"
reached_from: ["[[passage-02-three-days-west]]"]
fork_depth: 1
engagement: required
terminal: true
npcs: ["[[geoffrey-draves|Geoffrey Draves]]", "[[old-faas|Old Faas]]", "[[sem-holst|Sem Holst]]", "[[master-kyzil|Master Kyzil]]"]
monsters: []
statblocks: []
locations: ["[[high-eyrie|The High Eyrie]]", "[[the-drowned-maw|The Drowned Maw]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: f8cf5517-91fd-4229-b958-1abd55d2cc90
---

# Session 09, Moment 5: High Eyrie Approach

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-05-high-eyrie-approach-narration-open]]

![[moment-05-high-eyrie-approach-dialogue-geoffrey]]

## What Happens

The [[sentinels-of-the-eyrie|Sentinels of the Eyrie]] build no docks. The southern stair is rescue-and-drill work, never a visitor's entrance. On the eastern ledge, [[master-kyzil|Master Kyzil]] writes what arrives: hull colour, rig, heading, souls on deck. He adds nothing of his own. [[crissdalynn-khinriss|Crissdalynn]]'s exile ends on nothing but her own account of [[the-drowned-maw|The Drowned Maw]], and every line he writes now sits beside whatever she tells him.

Maw thermals push surface water west in surges. Where a surge meets the stack's base the sea piles up and breaks. The ring runs about two hundred yards out from the rock and keeps moving. A beam sea inside it can pin a shallow keel against basalt. Twenty feet of wet black rock stand between the waterline and the lowest tread, sheer, and salt-slick in this rain. Robed shapes watch from the upper terraces the whole way in. [[aarakocra|Aarakocra]] land on the terraces; everyone else comes up by invitation, harness, or a climb watched from above. Nobody flies the rest of a crew up.

As the *[[uncertainty|Uncertainty]]* closes on the ring, Kyzil drops from the ledge in one unhurried dive and comes level with the rail. He speaks to Crissdalynn alone, pitched low: keep the [[fate-spinner|dreidel]] closer than she's been keeping it, and let none of the masters see it, not one. Pressed, he says the same words again and folds his wings right over left before the ledge takes him back.

Hired watchers already sweep the [[midchain|Midchain]] for any Sentinel carrying a Fate Spinner. The dreidel has been opening her Long Sight early and unevenly, the one crack in a doctrine built to prevent exactly that. He fears someone will take it from her by force. He fears worse that its pull turns her the way it turned someone he loved once, years before her birth, from watching fate into spending it on herself.

If they stall on the water, the rain thickens and the swells build. Every hour outside the ring is another hour of the ledger recording a ship that came and did not commit, and another hour of the ring turning rougher under a rising tide.

## What they want

**The ask:** direct. [[geoffrey-draves|Geoffrey Draves]] wants a decision on the rope and the helm before the bow reaches the white water, and he names the distance before he names the danger.

## Checks

> [!check] Insight (DC 15) — Reading the Wind and Tide
> **Success:** his hands stall on the second fold; he has not given this warning before.
>
> **Failure:** no tell.

> [!check] Water Vehicles (DC 16, helm; advantage if a second PC calls surges from bow or crosstrees) — Holding Her Inside the Ring
> **Success:** she holds station off the southern face long enough for a line to go up.
>
> **Failure:** a surge takes her on the beam and pushes her out of the ring; the attempt costs an hour, the next run is in heavier rain, and **[[sem-holst|Sem Holst]]** wants the hull reinforced before a third try.

> [!check] Athletics (DC 15; advantage if a line is already fixed from above, disadvantage while carrying a second person's gear) — Twenty Feet of Wet Basalt
> **Success:** hands on the lowest tread.
>
> **Failure:** the climber drops into broken water at the base, takes **1d6 bludgeoning**, and needs a hand back to the boat.

> [!check] Perception (DC 13; free to whoever banked Lookout) — What the Ledger Says
> **Success:** the visible lines are hull colour and heading, nothing underlined twice.
>
> **Failure:** rain hides the page.

**If they're stuck on how to get up:**

- **Free tell:** unprompted, from the bow, Geoffrey says it plainly, the way he says everything.
- **Costed nudge:** a Sentinel drops a harness line from the lowest terrace with nobody asking, and the order records who needed it.
- **Bail-out:** Crissdalynn carries the crew up one at a time, three trips in this wind, with Kyzil at the ledge for every one of them.

## Next

The rain and the ring hold. The lowest tread is twenty feet up, wet, and Kyzil is back on the eastern ledge with the ledger. Anyone still on the water is still on the water. The crate and the barb are still unfinished, and the chair stays bolted in the dark of the aft cabin.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[geoffrey-draves|Geoffrey Draves]]
- [[old-faas|Old Faas]]
- [[sem-holst|Sem Holst]]
- [[master-kyzil|Master Kyzil]]
- [[sentinels-of-the-eyrie|Sentinels of the Eyrie]]
- [[high-eyrie|The High Eyrie]]
- [[the-drowned-maw|The Drowned Maw]]
