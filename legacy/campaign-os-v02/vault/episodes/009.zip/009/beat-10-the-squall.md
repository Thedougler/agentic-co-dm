---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
summary: A fast squall hits mid-crossing. Its warmth and its heading off the south tell a navigator the ship has already crossed into Midchain-warmed water, not the cooler Crown-side current it left.
engagement: optional
thread: "[[central-strait|Central Strait]]"
trigger: The crew is mid-crossing on any open-water passage leg, day or night.
if_ignored: Sails caught unreefed tear or a line parts under the gust. The ship loses half a day's progress to repairs, and the crew's confidence in whoever held the deck takes a visible knock.
ripens: ""
reusable: true
beat_number: 10
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: []
locations: []
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 10: The Squall

> [!read-aloud]
> Your skin knows before your eyes do. The wind swings a full quarter-turn in the space of a breath, dry air gone warm and wet in an instant. Look south and the horizon is already gone, swallowed by a wall of grey moving fast enough to watch, the air pressure dropping hard enough to feel in the ears. The sea changes color ahead of the rain, slate-dark under the shadow racing toward the hull, whitecaps stacking where the swell was flat minutes ago.

## What Happens

The Central Strait throws squalls fast and without much warning. The open water gives a storm nothing to break against before it arrives. This one is warm and comes out of the south, which means it rode up off [[midchain|Midchain]]'s own warmer water instead of sweeping down cold off the [[crown-islands|Crown Islands]]. The crew has minutes, not longer, to reef sail and lash anything loose before it's on them.

**The signal** is a warm squall out of the south. It means the ship is already sailing in water Midchain has warmed, not the cooler Crown-side stretch it left days back, so the crossing is further along than the chart alone would say.

**If they dig:** the squall's wind shift lines up with the edge of the Scatter Current. Past this point, the water runs faster and warmer clear through, a stretch of sea distinct from what the ship crossed to get here. The change is permanent, not a passing weather shift.

## Checks

> [!check] Wisdom (Survival) — Ride It Out
> **DC 12.** The crew reefs sail and secures cargo before the squall's full force hits.
> **Success:** the ship rides it out clean. Rain soaks the deck and shakes the crew, but they restore the heading within the hour.
> **Failure:** a line parts or a sail tears. The ship loses way and needs repair before the crossing continues.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[central-strait|Central Strait]]
