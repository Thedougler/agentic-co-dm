---
type: session
subtype: overview
status: pending
publish: false
aliases: ["Session 09 Overview", "s09 overview", "Session 09 Index"]
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, exploration, travel]
summary: "Episode entry for session 09: Aruhe, La Vasca, the heading, then destination walks."
tier: core
edit_pass: 0
session_number: 9
session_date: 2026-08-16
session_shape: crossing
world_date: "1495 DR"
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/overview.md"
uid: 3a9c1e70-2b4f-4d8a-9e11-6c0d8f2a4b17
---

# Session 09: Overview (The Open Strait)

## Read first

- [[threads]] · [[player-gravity]] · [[party-items]] — live pressure, what they bite on, what they carry
- [[sequence-01-cold-open-aruhe]] · [[aruhe-hungry-isle]] — the open and the island it depicts
- [[moment-02-la-vasca-departure]] · [[uncertainty-refit-tour]] — dock, tribute, the rebuilt ship
- [[moment-03-the-heading-choice]] · [[central-strait-crossing]] — five equal bearings on shared water
- [[velvet-noose-takes-the-lane]] · [[encounter-velvet-noose-intercept]] — claimed water
- Destinations: [[high-eyries-storm-door]] · [[sparholds-burning-challenge]] · [[kalowes-frozen-council]] · [[drowned-maws-open-shelf]] · [[fathomrushs-split-harbor]]
- People live on those pages: [[old-faas]] · [[geoffrey-draves]] · [[sem-holst]] · [[thunk]] · [[master-kyzil]]

## Tonight

- Shape: crossing
- Start: [[aruhe|Aruhe]]. A [[grung|Grung]] guardsman crosses beach, reef, and channel while the island takes the slowest survivors.
- Opening pressure: the island kills the slowest person in each zone.
- Opening stretch: [[e09-run-guide-open-strait|The Open Strait]]

## Run guides

- [[e09-run-guide-open-strait|The Open Strait]] — start here: Aruhe, [[calveno-la-vasca|La Vasca]], the heading
- [[uncertainty-refit-tour-run-guide|Refit Tour]] — they linger aboard before the lines go slack
- [[aruhe-hungry-isle-run-guide|Aruhe]] — they turn east or follow wreckage after the open
- [[velvet-noose-takes-the-lane-run-guide|Velvet Noose]] — claimed water, any bearing
- [[high-eyries-storm-door-run-guide|High Eyrie]] — they name west
- [[sparholds-burning-challenge-run-guide|Sparhold]] — they name south
- [[kalowes-frozen-council-run-guide|Kalowe]] — they name southwest
- [[drowned-maws-open-shelf-run-guide|the Maw]] — they name east
- [[fathomrushs-split-harbor-run-guide|Fathomrush]] — they name far east
