---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - intrigue
summary: A merchant vessel crosses their heading flying a pennant nobody aboard recognizes.
engagement: optional
thread: "[[khlysty|The Army, Not the Heir]]"
trigger: the crew is on open water and another sail comes into view on a crossing tack
if_ignored: the vessel passes unremarked; the crew loses the chance to spot Grigori's new banner before it becomes common on this route
ripens: the pennant starts appearing on more Midchain traffic, easier to place once seen twice
reusable: true
beat_number: 6
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: []
locations: []
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 6: Strange Pennant

> [!read-aloud]
> A merchant hull cuts across the horizon on a different tack, low and heavy in the water. Her lines are plain, her rigging unremarkable, yet the pennant snapping from her masthead matches nothing anyone aboard has ever charted.

## What Happens

A cog moves cargo through the [[midchain|Midchain]] under a banner none of the crew's charts or trade contacts can account for. The vessel keeps to a legitimate shipping lane. Her crew trims sail properly, the hail comes correct, and whoever flies this pennant wants the crossing seen, not hidden. The ship holds course and passes without incident.

**The signal**: the pennant is a design nobody recognizes, flown openly on a working merchant run instead of tucked away or swapped for a house flag once challenged.

**If they dig**: a hail, a spyglass count of the crew, or a later dockside inquiry turns up that the cog's manifest and crew rotation don't match any registered house or guild operating this route. The pennant marks a network moving quietly and consistently through the Midchain, one that answers to no port authority anyone can name.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[khlysty|Khlysty]]
- [[shepherd-grigori|Shepherd Grigori]]
