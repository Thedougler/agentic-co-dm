---
type: moment
status: draft
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [midchain, exploration]
summary: "A hip-height rope-scored lane runs inland from the yard: eleven roped men, nine unshod escorts, camp up the cut, ebb still running."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 15
world_date: "1495 DR"
reached_from: ["[[fork-02-the-burning-yard]]"]
fork_depth: 2
engagement: required
terminal: false
npcs: ["[[ussa]]"]
monsters: []
statblocks: []
locations: ["[[sparhold]]", "[[midchain]]"]
encounter: ""
campaigns: []
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: d4f0254d-e0ce-41be-9afb-c35e9890f981
---

# Session 09, Moment 15: The Green Cut Trail

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-15-the-green-cut-trail-narration-open]]

## What Happens

Two hundred feet past the palisade, [[ussa|Ussa]]'s chalk stops matching the ledger. [[petro-amaru|Amaru]]'s bought line runs a season deeper into [[grung-clans|Grung]] forest than the records admit. The raiders took these men cutting [[grung|Grung]] timber off that unrecorded book. [[sparhold|Sparhold]] wants the taking unread.

Fire and smoke held forty hands on the bucket line while the column worked a camp a mile and a half up-cut. The burning Green Cut is that raid's view from the water. The trail shows [[jean-claude-tabarnack|Jean-Claude]]'s [[corrigans-rest|Corrigan's Rest]] arithmetic: fighting-age men only, [[rope|roped]] at hip height, everything else left standing.

These men are [[grung-clans#Front: The Fighting-Age Levy|the Fighting-Age Levy]], bound for [[karath|Karath]]'s short-handed hatchery camps, sorted for age at the rope. Roped prisoners walk at half pace. The beached [[vethka|Vethka]] hulls must float before the ebb leaves them dry. The column clears the reef by evening or loses its ride out.

If they stall, the vanished crew becomes a two-day tally at Sparhold, filed under a boundary the ledger claims was never crossed. The lane is five hours old and drying. Roped men leave a slower, wider, plainer trail with every mile, so the gap closes as the sign fades. Past the tree line the clans hold sole jurisdiction. The boat waits on the shingle. The ebb still runs out.

## Checks

> [!check] Survival (DC 13, Jean-Claude auto-succeeds) — Reading the Lane
> **Success:** eleven roped men, nine unshod escorts, inland before dawn; one dragged leg; one age range; camp up the cut above the yard.
>
> **Failure:** booted and unshod tracks inland; no hour, no count.

**If they're stuck:**

- Free tell: the scored bark holds one fixed height for a mile. Any rope-line hand reads it.
- Costed nudge: shifting or climbing the felled spar burns time the column spends walking.
- Bail-out: the chalked trunks stand regardless, and read the same to [[crissdalynn-khinriss|Crissdalynn]]'s eye ten days on.

## Next

[[moment-08-sparhold-arrival|Sparhold Arrival]], whenever the crew turns back down the lane for the boat. The ebb is still running under the shingle, and the ridge sits four hours south whatever they carry down out of the trees.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[sparhold|Sparhold]]
- [[grung-clans|Grung Clans]]
- [[ussa|Ussa]]
- [[fork-02-the-burning-yard|The Burning Yard]], the fork that lands here
