---
type: moment
status: draft
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime, undead]
summary: "The Dead Lady surfaces off the port bow at last light, three days out, to collect Umberlee's Pearl debt — paid or owing from La Vasca's arch — with Fisk's drowned crew working her lines."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 11
world_date: "1495 DR"
reached_from: ["[[moment-10-the-brigantine]]"]
fork_depth: 1
engagement: required
terminal: true
npcs: ["[[old-faas|Old Faas]]", "[[geoffrey-draves|Geoffrey Draves]]", "[[sem-holst|Sem Holst]]", "[[thunk|Thunk]]"]
monsters: []
statblocks: []
locations: ["[[central-strait-crossing|The Central Strait Crossing]]", "[[kalowe|Kalowe]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: 68a8c9ce-e03b-447c-b19a-2b0cc59fe178
---

# Session 09, Moment 11: The Dead Lady Finds Them

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-11-the-dead-lady-finds-them-narration-open]]

![[moment-11-the-dead-lady-finds-them-dialogue-faas]]

## What Happens

Umberlee collects the [[pearl-of-souls|Pearl of Souls]]' debt now, and the *[[dead-lady|Dead Lady]]* is how she does it. No captain: Umberlee alone takes each boat whole, tribute over the side, hull left empty. She won't kill [[delmar-fisk|Delmar]]: it loses the five captains' souls to [[the-drowned-maw|the Maw]] again, and the Pearl needs him alive to return. She's held under the keel since the brigantine passed, waiting to rise.

She reads the ledger set at [[calveno-la-vasca|La Vasca]]'s arch ([[moment-02-la-vasca-departure|Moment 2]]) as a settlement officer reads a stamp.

- **Paid:** the mark sits in a [[waveservants|Waveservant]] basin at [[calveno|Calveno]] and in Faas's log. She holds twenty feet off the port bow, takes the measure of the deck, and by the middle watch slides off the horizon.
- **Owing:** nothing settled the account. A wrong-way current bleeds the hull's speed. The water turns deep-cold. She closes onto the port quarter, near enough by middle watch for a man to jump the gap.

Either way, she does not fire first and does not answer a hail.

The hands below her deck are the rank-and-file of [[fisks-fleet|Fisk's fleet]], roughly thirty drowned and silent. Anyone who sailed the *[[red-lady|Red Lady]]* knows those faces as individuals. They cross solid hull without opening it, need no port or grapnel. Nobody on the water has tied the red ship to the stolen Pearl. The faces on those decks are the tie, standing in plain sight at twenty feet.

## What they want

**The ask:** direct. Faas wants tribute over the port rail before she comes any further up, and he will not name the sum for them.

## Checks

![[dead-lady#Stats & Combat]]

> [!check] Perception (DC 14, from the rail or aloft) — Reading Her Decks
> **Success:** freeboard low enough to climb from a boat; sails full against a wind that is not filling them; figures work her lines and do not look up.
>
> **Failure:** red hull only; no deck read.

> [!check] History (DC 13, automatic for Fisk's Fleet veterans) — Whose Hands Those Are
> **Success:** faces from five drowned crews; rig and figurehead are the *[[red-lady|Red Lady]]*'s.
>
> **Failure:** no names.

**If they're stuck on what she is:**

- **Free tell:** the drumming beats one cadence no matter what the ship does. It belongs to the shape, not the sea.
- **Costed nudge:** Faas has heard the Kalowe-lane story of empty hulls with holds gone to the side. He'll tell it if someone stands at the rail with him now.
- **Bail-out:** the figurehead is the *Red Lady*'s own carved woman. Any crewman who sailed her says so outright.

## Next

She holds alongside in the dark. The only light on the water is the lantern on Faas's line and what it reaches of the figurehead twenty feet off the port bow. Four days of open water still stand between this deck and the dry dock at Kalowe, and nothing obliges her to leave by morning.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[old-faas|Old Faas]]
- [[sem-holst|Sem Holst]]
- [[geoffrey-draves|Geoffrey Draves]]
- [[thunk|Thunk]]
- [[dead-lady|Dead Lady]]
- [[umberlee|Umberlee]]
- [[waveservants|Waveservants]]
- [[pearl-of-souls|Pearl of Souls]]
- [[kalowe|Kalowe]]
