---
type: beat
status: draft
publish: false
aliases: []
created: 2026-08-12
updated: 2026-08-13
tags:
  - maritime
  - social
summary: A floating gnomish chandlery hails a passing ship first, trading rope and news for news.
engagement: optional
thread: "[[nimmik-vollask|Nimmik Vollask]]"
trigger: the crew is on open water, any crossing day
if_ignored: the *Nimmik Vollask* holds course and passes; the crew misses a resupply stop and whatever traffic on the water Cotter would have named
ripens: ""
reusable: true
beat_number: 9
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs:
  - "[[cotter-foss|Cotter Foss]]"
locations:
  - "[[nimmik-vollask|Nimmik Vollask]]"
encounter: ""
campaigns:
  - Shattered Sea
owner_skill: vault/episodes/.claude/skills/draft-beat/SKILL.md
---

# Session 09, Beat 9: The Depot

> [!read-aloud]
> A boxy orange hull closes on a crossing tack, riding low and ugly against the grey water, two-foot Gnomish letters running her full length. Her masthead pennant snaps in the wind, a coiled rope stitched over crossed nails, and she hails first, calling range and asking for a hold count before either ship needs to.
>
> Tar and frying meatballs carry across the gap on the wind.

## What Happens

The *Nimmik Vollask* works the [[central-strait|Central Strait]] on a standing circuit, and any ship crossing that water long enough eventually meets her. She is not hunting cargo or scouting targets. She sells rope, pitch, nails, and fresh water off a below-decks stock sixty gnomes keep packed and ready, and [[cotter-foss|Cotter Foss]] runs the sale from the rail with a ledger and a coffee pot.

**Her pennant and her hail are the signal.** She calls range and names herself before the crew has to decide anything, closing on her own terms, ready to sell instead of raid.

**If they dig:** Cotter trades news for news. Every ship that pulls alongside pays in cargo fees and in what it's seen. She keeps a running count of who's moving where on this strait, and a fair trade of information gets a fair trade back.

## Next

[[e09-run-guide|Session 09 Run Guide]]

## Connections

- [[e09-run-guide|Session 09 Run Guide]]
- [[nimmik-vollask|Nimmik Vollask]]
- [[cotter-foss|Cotter Foss]]
