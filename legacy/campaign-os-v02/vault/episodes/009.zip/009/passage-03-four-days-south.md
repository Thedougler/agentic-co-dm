---
type: passage
status: pending
publish: false
aliases: ["Four Days South", "South Crossing"]
created: "2026-08-11"
updated: "2026-08-13"
tags: [maritime, travel]
summary: "Four days south to Sparhold through busy merchant water, with empty docks at Corrigan's Rest, smoke on the coast, and a crew arriving tired under martial law."
method: ship
distance: Far
duration: "four days"
from_moment: "[[fork-01-the-heading-choice]]"
destination: "Sparhold"
reconverges_at:
beats:
  - "[[beat-02-empty-docks]]"
  - "[[beat-03-waveservant-wreckage]]"
  - "[[beat-04-smoke-on-the-coast]]"
  - "[[beat-06-strange-pennant]]"
  - "[[beat-08-the-chemical-story]]"
  - "[[beat-09-the-depot]]"
  - "[[beat-10-the-squall]]"
conditions: "Charted merchant water, one landfall at Corrigan's Rest on the second afternoon"
passage_number: 3
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: ["[[geoffrey-draves|Geoffrey Draves]]", "[[old-faas|Old Faas]]", "[[sem-holst|Sem Holst]]", "[[thunk|Thunk]]", "[[master-kyzil|Master Kyzil]]"]
locations: ["[[calveno|Calveno]]", "[[midchain-north]]", "[[corrigans-rest|Corrigan's Rest]]", "[[sparhold|Sparhold]]"]
campaigns: [Shattered Sea]
owner_skill: "vault/episodes/.claude/skills/draft-passage/SKILL.md"
---

# Session 9, Passage 3: Four Days South

## Departure Cost

Choosing south defers the [[high-eyrie|High Eyrie]] and the Maw. The crew takes the busiest lane in the chain, charted merchant water thick with traffic that might recognise the *[[uncertainty|Uncertainty]]* under its new paint. Whatever waits at the Eyrie waits longer, and the Maw's opening moves while the ship runs south.

## The Crossing

The *[[uncertainty|Uncertainty]]* runs four days of chain, island after island, mangrove green giving way to limestone grey, a hillside here and there gone raw brown where the rains carried it into the sea. One landfall comes at [[corrigans-rest|Corrigan's Rest]] on the second afternoon. The retired crew's quiet island has boats on every mooring and only old hands in sight. The heading ends at [[sparhold|Sparhold]], a fortress-market under martial law with a death-duel already on the books, and on the fourth morning smoke rises off the coast four hours before the harbour walls.

## Roles

[[geoffrey-draves|Geoffrey Draves]] comes aft with a chart squared under one arm and waits. He wants a station named for every hand aboard and a decision on how close to run the island chain. Close in among the islands costs speed but carries cover. The open lane runs faster with none. He has no preference between the two and says so if pressed.

![[ship-operations#Stations Underway]]

Navigator, Lookout, Quartermaster, Bosun, and Captain cover the crossing. A post left uncalled takes its failure side unanswered. Without a Lookout, the leg's trouble arrives unannounced. Without a Quartermaster or Bosun, a cask goes over on the third day or a sail order fails at the critical moment.

## Group Check

> [!check] Group Survival — Four Days on the Southbound Watches
> **Critical Failure (5-25):** a squall drives them ten miles east of their line and breaks the galley stores loose across the scuppers, and the fourth-morning landfall slips to the fourth afternoon.
>
> **Failure (26-49):** four days of hard sailing on short sleep, every station's watch running long, and the crew reach Sparhold tired enough that the first person to raise a voice at them gets a reaction.
>
> **Success (50-74):** the crossing runs true, and the crew make Sparhold on Geoffrey's stated morning with the ship in order.
>
> **Critical Success (75+):** they cut inside two reef passages Geoffrey would have gone around and raise the coast half a day early, in light good enough to read the shore from beyond the range at which anyone on it reads them.

## Beat Menu

| # | Beat file | Type | Trigger |
|---|---|---|---|
| 2 | [[beat-02-empty-docks]] | optional | A Midchain coastal settlement comes into view with its boats still tied up |
| 3 | [[beat-03-waveservant-wreckage\|Waveservant Wreckage]] | optional | Open horizon in daylight, a stripped hull drifts into view |
| 4 | [[beat-04-smoke-on-the-coast]] | optional | Smoke rises off the coast and empty barques run north |
| 6 | [[beat-06-strange-pennant]] | optional | Another sail crosses the heading under an unknown pennant |
| 8 | [[beat-08-the-chemical-story]] | optional | The crew checks or restocks the reagent stores after two days at sea |
| 9 | [[beat-09-the-depot]] | optional | Orange hull broad on the beam, second morning out of Calveno |
| 10 | [[beat-10-the-squall]] | optional | Squall shelf closes from the northwest, third day |

## Landmark

At [[corrigans-rest|Corrigan's Rest]], cottages stand above the cove with laundry out, an old woman waves from the porch, and boats sit on moorings with nobody in them. The [[grung-clans|Fighting-Age Levy]] took the fighting-age hands and left the mouths. The pattern is the same as [[calveno|Calveno]] and six settlements before it, and the crew's heading is the levy's heading.

## Toll

Four days of hard sailing on watches that run long. The crew reaches [[sparhold|Sparhold]] tired enough that the first person to raise a voice at them gets a reaction.

## Arrival Changed

Fire on the coast and traffic running north in empty convoy tell the crew the timber dispute has already turned physical before they reach [[sparhold|Sparhold]]. Whatever the levy left behind at [[corrigans-rest|Corrigan's Rest]] is heading the same direction they are.

## Next

[[sparhold|Sparhold]], when the crossing ends.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[sparhold|Sparhold]]
- [[corrigans-rest|Corrigan's Rest]]
