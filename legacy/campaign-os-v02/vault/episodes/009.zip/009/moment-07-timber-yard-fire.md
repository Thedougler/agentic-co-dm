---
type: moment
status: pending
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime, midchain, exploration]
summary: "A burning Kailani timber yard four hours north of Sparhold carries Grung sap on its cut line; one boat and four hours reach only one thing before barques take the news south."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 7
world_date: "1495 DR"
reached_from: ["[[passage-03-four-days-south]]"]
fork_depth: 1
engagement: required
terminal: false
npcs: []
monsters: []
statblocks: []
locations: ["[[campaigns/shattered-sea/locations/midchain/sparhold]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: d6cdee6b-74a7-492c-88a4-fd7eb439d1ae
---

# Session 09, Moment 7: The Timber Yard Fire

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-07-timber-yard-fire-narration-open]]

## What Happens

The yard burns from processed tree-sap poured from the forest. Only [[grung-clans|Grung]] raiders use that accelerant. A fistful ties this fire to [[house-kailani|House Kailani]]'s account of territory raids. The boundary itself (earnings, ledger claims, scout bribes) belongs to [[sparhold|Sparhold]]'s Green Cut, a clock the crew does not hold.

One stack is already charcoal. The second catches within the hour while the bucket line still works it. Fire eats base to top.

Barques running north reach Sparhold ahead of the crew with news of a blue-black hull standing off a burning Kailani yard. One boat sits on the davits. The ridge is four hours south either way.

## Checks

> [!check] Investigation (DC 13, ashore only; [[jean-claude-tabarnack|Jean-Claude]] auto-succeeds) — The Cut-Boundary Stacks
> **Success:** hardened sap runnels sit glassy in the trunk gaps, poured from the forest side; a fistful comes away whole and keeps.
>
> **Success by 5+:** two pour lines met in the middle before first light, one pair of hands from each end.
>
> **Failure:** no source, no sample.

**If they're stuck:** any hand from a raided village names the smell aloud at no cost. Short that, a cutter off the bucket line will trade the same answer for two crew on his buckets. The sap itself won't wash, and it keeps on the shingle for a return trip inside the four hours.

## Next

[[fork-02-the-burning-yard|The Burning Yard]], as soon as the crew names what the four hours go to.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[sparhold|Sparhold]]
- [[house-kailani|House Kailani]]
- [[grung-clans|Grung Clans]]
