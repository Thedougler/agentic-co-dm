---
type: moment
status: pending
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime]
summary: "The crew explores the newly refit Uncertainty before Old Faas asks whether they pay Umberlee's tribute and cast off."
tier: supporting
edit_pass: 0
used_by: ["[[e09-run-guide-open-strait]]"]
session_number: 9
moment_number: 2
world_date: "1495 DR"
reached_from: []
fork_depth: 0
engagement: required
terminal: false
npcs: ["[[old-faas]]", "[[sem-holst]]", "[[geoffrey-draves]]", "[[thunk]]"]
monsters: []
statblocks: []
locations: ["[[calveno-la-vasca]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: db70cc0f-d3e0-4034-b531-a6d9fe5f77e3
---

# Session 09, Moment 2: La Vasca Departure

![[moment-02-la-vasca-departure-narration-open]]

## What Happens

The weather deck, gun deck, hold, chart archive, rigger's workshop, provisions store, long table, [[fleet-commanders-chair|Fleet Commander's Chair]], figurehead, and the open cook, navigator, and surgeon roles sit ready to inspect, claim, rename, test, stock, or leave. [[uncertainty-refit-tour|Uncertainty's Refit Tour]] holds the full live condition.

The tide keeps drawing the hull toward the arch.

## What they want

**The ask:** direct. [[old-faas|Old Faas]] holds a coin over the basin. He wants a yes or a no before the arch passes over the mast.

## Connections

- [[old-faas|Old Faas]]
- [[sem-holst|Sem Holst]]
- [[geoffrey-draves|Geoffrey Draves]]
- [[thunk|Thunk]]
- [[calveno-la-vasca|La Vasca]]
- [[uncertainty-refit-tour|Uncertainty's Refit Tour]]
