---
type: moment
status: pending
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime, exploration]
summary: "The Uncertainty sits over the Maw's western shelf: warm still water, ruin-tops forty feet down, and a line that must wait on the heat pulse."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 13
world_date: "1495 DR"
reached_from: ["[[passage-05-four-days-east]]"]
fork_depth: 1
engagement: required
terminal: false
npcs: ["[[old-faas|Old Faas]]", "[[thunk|Thunk]]", "[[sem-holst|Sem Holst]]"]
monsters: []
statblocks: []
locations: ["[[shelfworks|Shelfworks]]", "[[the-drowned-maw|The Drowned Maw]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: cae7ca01-b41c-48ff-bf54-096dea5bd493
---

# Session 09, Moment 13: The Shelfworks

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-13-the-shelfworks-narration-open]]

![[moment-13-the-shelfworks-dialogue-faas]]

## What Happens

[[catarina-davirelli|Catarina]] stripped the terrace above sixty feet: bare stone and empty hooks. At eighty feet the [[shelfworks|Shelfworks]] workshops still hang [[antheri|Antheri]] alloy tools in five-fingered hooks, uncorroded since the heat stopped all work. One intact bench sits on the seabed; its counterpart lies folded in canvas in the hold.

The warm layer sat deep in 1488. It sits at forty feet now. By dusk it will sit at the surface. A Maw-crossing ship logged the same warm patch and dead-fish smell as a vent and sailed on. Nobody aboard the *[[uncertainty|Uncertainty]]* knows what heats the water.

[[old-faas|Old Faas]] will not enter the water at any price. [[thunk|Thunk]] does not fit through a bell hatch. [[sem-holst|Sem Holst]] will dive if asked outright. He reads workshops as fallen timber and surfaces with corroded scraps and a spent dive's daylight.

## What they want

**The ask:** direct. [[old-faas|Old Faas]] wants a number — how long the ship sits over the shelf — before he drops the hook.

## Checks

> [!mechanic] The warm layer
> The water is blood-warm at 40 feet and hotter with depth; at 80 feet it
> shimmers visibly. Any rope, line, or lashing left in the layer parts on a
> pulse after roughly ten minutes of exposure, no roll: the pulse carries the
> hazard, not the heat's average. Anything hauling on that rope when it goes
> falls or drops. The heat leaves alloy, glass, and stone alone; it takes
> hemp, canvas, wax seals, and skin.

> [!check] [[wisdom|Wisdom]] (Survival) or [[intelligence|Intelligence]] (Investigation) (DC 12) — Reading the Shimmer Before Committing a Line
> **Success:** pulse period is clean for the next hour; a line worked between hot minutes survives.
>
> **Failure:** first line into the layer goes in blind.

**If nobody gets down:** the shimmer is free, and anyone at the rail sees
where the warm water starts without a roll. Sem Holst offers to go down if
the silence runs long, and costs a dive's daylight for junk. Failing that,
the stripped terrace at sixty feet sits in cool water, inside reach of the
gear already on deck. Bare hooks and empty benches up there, plus one floor
channel cut in a branch pattern that runs down-slope toward the level nobody
has touched.

## Next

[[moment-14-vestra-water|Vestra Water]], the shelf runs east from here and the water ahead is warmer still.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[old-faas|Old Faas]]
- [[thunk|Thunk]]
- [[sem-holst|Sem Holst]]
