---
type: moment
status: pending
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [maritime, undead, horror]
summary: "A silent red brigantine holds two miles off the Uncertainty's quarter, pressing Delmar's unpaid Umberlee debt toward The Drowned Maw."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 10
world_date: "1495 DR"
reached_from: ["[[passage-04-seven-days-southwest]]"]
fork_depth: 1
engagement: required
terminal: false
npcs: ["[[old-faas|Old Faas]]", "[[geoffrey-draves|Geoffrey Draves]]"]
monsters: []
statblocks: []
locations: ["[[central-strait-crossing|The Central Strait Crossing]]", "[[kalowe|Kalowe]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: 92931ec1-7f6a-4b14-a8e7-6b1d95d64320
---

# Session 09, Moment 10: The Brigantine

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-10-the-brigantine-narration-open]]

![[moment-10-the-brigantine-dialogue-faas]]

## What Happens

The red hull is the *[[dead-lady|Dead Lady]]*. [[umberlee|Umberlee]] is collecting [[delmar-fisk|Delmar]]'s [[pearl-of-souls|Pearl of Souls]] debt with the *[[red-lady|Red Lady]]*'s drowned hands. She holds two miles off the quarter at dawn and dusk and does not close.

Coin in the [[calveno-la-vasca|La Vasca]] basin clears her from the horizon by dusk. Debt carried out keeps her on the quarter, closer each hour.

Nobody aboard has spoken her name. While she holds station, a boat on a charted lane goes adrift with her hold emptied. Word of it reaches [[kalowe|Kalowe]] on faster water than this crossing.

## What they want

**The ask:** direct. [[old-faas|Old Faas]] wants to know if the crew laid coin in the basin before he writes the sighting in the log.

## Checks

> [!check] Perception (DC 15, with the glass or a clear line from the crosstrees; advantage in the first hour of light) — Reading Her Deck Through the Glass
> **Success:** empty deck; helm lashed; freeboard low enough to board from a boat; wake thinner than her speed should leave.
>
> **Failure:** red hull, bare masthead, same bearing.

> [!check] History (DC 15, anyone who works ships; automatic for [[fisks-fleet|Fisk's Fleet]] veterans and the five captains riding in Delmar's skull) — Her Lines and Her Yard
> **Success:** ninety-odd feet, seven ports a side, red worked into the wood; a [[chain-council|Chain Council]] build, same yard and rig as the *[[red-lady|Red Lady]]*.
>
> **Failure:** southern-style hull; no yard named.

> [!mechanic]
> **She keeps the range.** Alter toward her and she falls off the same number of points; alter away and she takes the same points back, holding two miles through every trick the chart or the weather offers. A hail comes back as silence, and so does a lamp. Nothing aboard her shows itself while the range holds, and the range holds while the light does.

If stuck:

- **Free tell:** Faas unprompted on the second sighting
- **Costed nudge:** [[geoffrey-draves|Geoffrey]]'s logged bearings prove constancy (costs a half-watch course change)
- **Bail-out:** the five captains speak her yard and builder when they see her

## Next

[[moment-11-the-dead-lady-finds-them|The Dead Lady Finds Them]], the range she has held all day is hers to spend, and the sun goes into the water at a quarter past seven.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[old-faas|Old Faas]]
- [[geoffrey-draves|Geoffrey Draves]]
- [[dead-lady|Dead Lady]]
- [[red-lady|Red Lady]]
- [[umberlee|Umberlee]]
- [[kalowe|Kalowe]]
- [[central-strait-crossing|The Central Strait Crossing]]
