---
type: narration
status: pending
publish: false
aliases: []
summary: "A ram the size of a draft horse tears out of Aruhe's brush toward the bearded captive."
goal: "Aruhe's first predator is taking the old man."
created: "2026-08-14"
updated: "2026-08-14"
tags: [survival, maritime, horror]
mode: continue
parent: "[[sequence-01-cold-open-aruhe]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: a1b2c3d4-e5f6-4789-a012-3456789abc02
---

> [!narration]
> *The brush does not part. It shreds sideways, and a ram the size of a draft horse comes through antlers-first, one horn taking a young mangrove out of the ground, root-ball still hanging, without breaking stride. Tendons stand in its neck like dock rope. Eyes flat black, they slide across the group the way a man looks at furniture he is about to move. Wet wool, and something sweet gone wrong underneath.*
>
> *The bearded man still holds the berry. Juice has reached his elbow. The ram's head is already lowering, the whole front of it dropping into the charge.*
