---
type: dialogue
status: pending
publish: false
aliases: []
summary: "Old Faas wants a number before the hook goes down."
goal: "He wants a sounding before anyone puts a hook down."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, exploration]
parent: "[[moment-13-the-shelfworks]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: a99f79b1-2f9e-457e-929d-215b83efe068
---

> [!dialogue]
> *[[old-faas|Old Faas]]*: I want a number before the hook goes down. How long are we sitting over this.
