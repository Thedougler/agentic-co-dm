---
type: narration
status: pending
publish: false
aliases: []
summary: "A dorsal fin saws the last half-mile of open water to Karath."
goal: "Open water to Karath is the last killing ground."
created: "2026-08-14"
updated: "2026-08-14"
tags: [survival, maritime, horror]
mode: continue
parent: "[[sequence-01-cold-open-aruhe]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: a1b2c3d4-e5f6-4789-a012-3456789abc06
---

> [!narration]
> *Half a mile of open water to [[karath|Karath]]: flat blue going down farther than the eye can hold, no reef under the feet, nothing to stand on if the arms stop.*
>
> *Karath is a dark line of stone, close enough to name, not close enough to touch. The water behind humps. A dorsal fin cuts the surface, sawing in short jerks too fast for the bulk underneath, and the wake lifts the legs and drops them, and the fin is closer when they come back down, a pale scar that runs into the water and does not end.*
