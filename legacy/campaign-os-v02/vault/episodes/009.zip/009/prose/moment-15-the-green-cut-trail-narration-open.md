---
type: narration
status: pending
publish: false
aliases: []
summary: "A hip-scored lane into still green: same-age stumps, ants that will not touch the sap, chalk on a felled spar."
goal: "The Green Cut is a same-age cut the forest will not reclaim."
created: "2026-08-14"
updated: "2026-08-14"
tags: [exploration, intrigue]
mode: establish
parent: "[[moment-15-the-green-cut-trail]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 077378e8-e39b-48e4-9bb0-54d3aebe9072
---

> [!narration]
> *The lane of tramped mud runs up through the felled rows and into the trees, hip-wide, scored, still wet in the prints. Four hundred feet in the yard is a smell and not a sound. The green closes over the lane three paces deep. The air stands still and sweats, leaf rot first, then a sweetness already on the tongue this morning. Neither insect nor bird answers.*
>
> *Boot prints run up it in a close double file. Around them lie splayed, webbed, unshod prints. [[rope|Rope]] has scored the bark at hip-height on both sides, one height the whole way. Cutters took the trees at the same age, the stumps still bleeding sap that ants will not touch. Sixty feet ahead a spar-trunk lies across the trail, white chalk at eye height.*
>
> *How do you move up the trail?*
