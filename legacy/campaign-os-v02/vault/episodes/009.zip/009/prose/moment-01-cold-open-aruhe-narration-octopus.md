---
type: narration
status: pending
publish: false
aliases: []
summary: "A suckered arm rises from the kelp and finds the younger Grung's spear-arm."
goal: "Something in the kelp has the younger Grung."
created: "2026-08-14"
updated: "2026-08-14"
tags: [survival, maritime, horror]
mode: continue
parent: "[[sequence-01-cold-open-aruhe]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: a1b2c3d4-e5f6-4789-a012-3456789abc05
---

> [!narration]
> *The kelp hangs in long curtains, old bronze gone green, thick enough to close over a head, and the water is quiet here in a way that is worse than noise. The weed gathers against the current. Something underneath wraps a trailing leg, soft, then tight, suckers finding wet skin as if they have done this before and are not in a hurry.*
>
> *The younger [[grung|Grung]], the one who has not spoken since the beach, is two body lengths to the right when a suckered arm rises out of the weed, pale, ringed, and finds his spear-arm at the elbow. The spear tilts.*
