---
type: narration
status: pending
publish: false
aliases: []
summary: "Morning in La Vasca's covered basin: tannery damp, Sem on one seam, Thunk feeding the galley, Faas watching the last line take slack."
goal: "The Uncertainty can sail; Umberlee's tribute is still unpaid."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime]
mode: establish
parent: "[[moment-02-la-vasca-departure]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: b2c3d4e5-f6a7-4890-b123-4567890bcd01
---
> [!narration]
> *The covered basin at [[calveno-la-vasca|La Vasca]] still smells of the tannery it pretends to be, mineral damp and a sour hide-note. One oil lamp hangs over the empty cradle. The tide knocks the fitted stone of the arch, a sound that comes up through the soles.*
>
> *[[sem-holst|Sem Holst]] works a thumb along a single caulk line amidships until the joint answers. [[thunk|Thunk]] walks a cask toward the unlit galley, the coin pouch knocking the combing. [[old-faas|Old Faas]] stands at the rail, brass ferrules planted, and watches the last mooring take slack. The wet line creaks. Nobody has put a name on the cook post, or the chart, or the woman at the bow.*
>
> *Is there anything you want to do before she sails?*
