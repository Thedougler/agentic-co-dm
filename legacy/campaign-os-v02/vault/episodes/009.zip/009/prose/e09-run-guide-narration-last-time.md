---
type: narration
status: pending
publish: false
aliases: []
summary: "Osset's name came loose in two mouths; Nona's hulls sit days behind; the Uncertainty's last line is still on the arch."
goal: "Osset is a named crack in the Sentinels; Nona's hunt is days behind; they have not left La Vasca."
created: 2026-08-14
updated: 2026-08-14
tags:
  - maritime
  - exploration
  - travel
mode: recap
parent: "[[e09-run-guide-open-strait]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: d4e5f6a7-b8c9-4012-d345-6789012def03
---
> [!narration]
> *Last time on the [[shattered-sea|Shattered Sea]] [[osset|Osset]]'s name came loose in two mouths, on two sides of a schism nobody aboard had heard named, and it sat in the air afterward the way a dropped plate sits, still ringing.*
>
> *A torn page off [[cabinet-of-morsani|Morsani]]'s shelf called him a monk who left the Sentinels and never came back. Down the canal, under lamps that smoked and a crowd that did not, [[lavinia-sordi|Lavinia]] sold [[crissdalynn-khinriss|Crissdalynn]] a cloak she called protection, the cloth cold even in the heat of the stall, and Identify made it cursed, a displacement that would not sit still on the shoulders. Lavinia named the same falcon-featured man as the seller, as if the name were ordinary coin and not a crack in a house Crissdalynn has never heard spoken that way.*
>
> *[[jean-claude-tabarnack|Jean-Claude]] read the raids as slaving by proxy: take the fighting-age men, leave the rest, wait. Fighting-age names stacked past three hundred and fourteen on [[nona-black-jaw|Nona]]'s borrowed table in the [[mercatura|Mercatura]] crater, ink still wet on the last line, the queue thinning only when she stood and vowed it aloud. [[grung|Grung]] poison was already showing on ships that traded with the raiders, a green smell in the holds, a stain that would not wash. Nona sent two hulls from [[the-passage|The Passage]] days behind, and she gave [[perrin-black-jaw|Perrin]] a favor instead of a cash share, and word that [[cobb|Cobb]]'s refit would be ready in twelve hours.*
>
> *This morning those twelve hours are spent. The *[[uncertainty|Uncertainty]]*'s last line is still on the arch at [[calveno-la-vasca|La Vasca]], wet paint on a hull that used to have another name, and the water beyond the basin.*
