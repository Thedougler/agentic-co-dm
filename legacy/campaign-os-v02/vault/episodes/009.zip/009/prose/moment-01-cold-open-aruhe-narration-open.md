---
type: narration
status: pending
publish: false
aliases: []
summary: "A Grung wakes face-down in Aruhe's surf; captives sit under the hull; a berry splits in a bearded man's hand."
goal: "They are Grung on Aruhe; the island is already killing captives."
created: "2026-08-14"
updated: "2026-08-14"
tags: [survival, maritime, horror]
mode: establish
parent: "[[sequence-01-cold-open-aruhe]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: a1b2c3d4-e5f6-4789-a012-3456789abc01
---

> [!narration]
> *Face-down in six inches of water, sand packed in the teeth, the spear still locked in a purple fist that has not decided to let go.*
>
> *Upright, [[aruhe|Aruhe]]'s trees stand a wall, fruit rotting under fruit still ripening so the air coats the roof of the mouth. In the shade of the broken hull three captives sit: the long-hair, both hands locked in the shirt of the branded one, whose left shoulder carries a raw iron mark, and an older one, long-bearded, already on his feet. Two [[grung|Grung]] crouch in the surf, the scarred-lip one and the younger who has not spoken, and no bird answers them. The bearded man picks a berry the size of a peach. The skin splits. Juice runs to the elbow, dark, and his hand is already halfway to his mouth.*
>
> *What do you do?*
