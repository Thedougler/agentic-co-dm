---
type: narration
status: pending
publish: false
aliases: []
summary: "A crocodile longer than the wrecked boat waits in the gap between reef and deep water."
goal: "Deep water starts here; the scarred-lip Grung is next."
created: "2026-08-14"
updated: "2026-08-14"
tags: [survival, maritime, horror]
mode: continue
parent: "[[sequence-01-cold-open-aruhe]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: a1b2c3d4-e5f6-4789-a012-3456789abc04
---

> [!narration]
> *The reef shelf drops away and the water goes green-dark. Behind, the elk lies on the coral with its legs buckled at four wrong angles, screaming the same pitch the ram made.*
>
> *Ahead a [[giant-crocodile|crocodile]] longer than the wrecked boat lies with its jaws cracked an inch apart, teeth the colour of old ivory. One yellow eye rolls up, finds the nearest movement, and does not blink. The scarred-lip spearman is on the wrong side of a body-width gap, and the water around that flank is already moving in a way the swell does not explain.*
