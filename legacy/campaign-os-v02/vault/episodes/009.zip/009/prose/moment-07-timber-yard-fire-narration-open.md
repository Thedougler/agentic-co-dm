---
type: narration
status: pending
publish: false
aliases: []
summary: "A living yard dying: hide-slick palms, glassy cut-faces, a smack that will not work, barques already choosing south."
goal: "Sparhold's yard is burning and the evidence is leaving."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, intrigue]
mode: establish
parent: "[[moment-07-timber-yard-fire]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 725f3601-42cb-4117-a8b7-2058e110afca
---

> [!narration]
> *On the fourth morning the glass finds the smoke before the sun is clear of the water. Twelve hundred feet off the port bow a timber yard is dying inside its own fence, the fire working a stack from the ground up.*
>
> *The split-thumb has been passing the same hide for an hour, a brown slick on both palms that will not rinse. The creek has gone to shin-mud and a sweet boiled smell, like syrup left on a hot pan. Where the flame finds the cut faces the wood goes glassy, as if someone had varnished it in the night.*
>
> *A fishing smack in [[house-kailani|Kailani]] green and bone-white lies off the beach, boarding axes across the knees of the six aboard her. The landward gate stands open on a lane of tramped prints that goes inland and does not come back.*
>
> *What do you do?*
