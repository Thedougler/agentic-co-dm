---
type: narration
status: pending
publish: false
aliases: []
summary: "Dawn on a working cutter: Sem at a seam, Thunk at a muzzle, and a red hull that keeps two measured miles and makes no sound."
goal: "A silent red hull is matching them at two miles."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, horror]
mode: establish
parent: "[[moment-10-the-brigantine]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: d97296f1-4a8d-4b42-a126-6987d86945d0
---

> [!narration]
> *The sun lays one hard copper line across the water. A brigantine holds station off the stern quarter, two miles back. Her hull is the colour a wound goes about an hour in. Nothing flies from her at all.*
>
> *The northeast wind has been on the *[[uncertainty|Uncertainty]]*'s quarter since dawn. [[sem-holst|Sem Holst]] is already at a seam he does not need to test. [[thunk|Thunk]] has a swab in a muzzle. A hull that size at two miles ought to send a boom under the bow. Nothing reaches. Each slap against the stem arrives alone.*
>
> *The angle has not moved. Not a point. [[old-faas|Old Faas]] puts the glass on her and holds it. Through it her canvas stands full on the wrong side of the wind, and still she keeps the same two miles, as if the sea between the hulls were a measured rope.*
>
> *What do you do?*
