---
type: dialogue
status: pending
publish: false
aliases: []
summary: "Old Faas wants tribute over the port rail now and will not name the sum."
goal: "Tribute is due over the rail now; he will not name the sum."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, horror]
parent: "[[moment-11-the-dead-lady-finds-them]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 0d10f70a-6f52-49ad-8339-2068f4852567
---

> [!dialogue]
> *[[old-faas|Old Faas]]*: Whatever goes over that rail goes now. I will not name the sum. Over the port side before she comes any further up.
