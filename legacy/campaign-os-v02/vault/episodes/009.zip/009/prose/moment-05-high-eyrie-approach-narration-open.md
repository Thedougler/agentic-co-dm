---
type: narration
status: pending
publish: false
aliases: []
summary: "Sideways rain and a white ring close a stack that flies no banner; Faas watches the water ahead of it while a pale-disc writes."
goal: "Storm water closes the Eyrie; there is no dock."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, exploration]
mode: establish
parent: "[[moment-05-high-eyrie-approach]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 4b2e71e8-116a-4e2c-a24a-9b9a915d74dc
---

> [!narration]
> *The rain arrives sideways and finds the teeth first. By noon the [[high-eyrie|High Eyrie]] is a wet wall of basalt two hundred feet out of the sea, spray climbing it tasting of iron. Nothing flies a banner.*
>
> *Two hundred yards out the water goes white in a ring and stays white. Inside it the surface lifts, drops, shoves sideways, and leaves no foam in the same place twice. [[old-faas|Old Faas]] has the wheel in both fists, brass ferrules planted, and he looks at the water just ahead of the ring.*
>
> *On the highest ledge a pale-disc in a darkening tawny mantle keeps a ledger open against the rain, and the ink runs as it finds the page. He adds nothing that is not a hull colour or a heading. The southern face carries a cut stair that stops short, salt-slick.*
>
> *What now?*
