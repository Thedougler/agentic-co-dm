---
type: dialogue
status: pending
publish: false
aliases: []
summary: "Faas names this water as the Vestra's grave. Thunk does not like a still that warm."
goal: "This water is the Vestra's grave."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, horror]
parent: "[[moment-14-vestra-water]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: f28d9dc0-38fb-41f5-aeb9-1dd7e0ca1fb4
---

> [!dialogue]
> **[[old-faas|Old Faas]]**: [[perrin-black-jaw|Perrin]]. Your grandmother told me what happened to the *[[vestra|Vestra]]*. She told me where. This is the place. Take it as that.
>
> **[[thunk|Thunk]]**: The water is too still. I do not like a still that warm.
>
> **Old Faas**: Ja. It will come back. How do you want her pointed?
