---
type: narration
status: pending
publish: false
aliases: []
summary: "Amaru measures the boundary rows toe-to-heel, one ledger face on a stump, while the corded-hair watches the trees."
goal: "Amaru is measuring the burned boundary for House Kailani."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, intrigue]
mode: establish
parent: "[[moment-16-the-kailani-smack]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: c300d04f-56cb-4fb6-9a8b-bc21c9706c92
---

> [!narration]
> *The smack puts her nose on the shingle sixty feet down-beach from the *[[uncertainty|Uncertainty]]*'s own boat, keel grinding once, then still. Nobody in her stands up. The corded-hair is green-skinned, chalk still white in the creases of both palms, and her eyes stay on the tree line.*
>
> *He is broad, worn leather, a ledger held up clear of the water. He walks the boundary rows first, toe-to-heel along the cut. He writes a width, then another, and sets the ledger open on the nearest stump so the yard can see one face of it.*
>
> *Then he sees the blue-black hull standing off, paint still tacky, and the pencil goes behind his ear. The wet stone at the waterline is already a hand wider than when he stepped down. He comes up the shingle with the ledger open.*
>
> *How do you answer him?*
