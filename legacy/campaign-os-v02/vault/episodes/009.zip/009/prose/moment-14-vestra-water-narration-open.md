---
type: narration
status: pending
publish: false
aliases: []
summary: "A chalk-cut of heat kills the swell. Geoffrey's lead comes up steaming. A mass lifts the hull once and runs east."
goal: "Heat killed the swell; something large ran east under them."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, horror]
mode: establish
parent: "[[moment-14-vestra-water]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 6e1c3718-aa61-4bd8-aa62-2c5d0d9c9839
---

> [!narration]
> *The heat arrives at the bow first, a line ruled across the ocean as clean as a chalk cut. Cold water astern, blood-warm water forward. The swell dies. The surface sets like poured glass, and the *[[uncertainty|Uncertainty]]* hangs between two identical blues, and the silence where the slap of the stem used to be.*
>
> *[[geoffrey-draves|Geoffrey]] has a lead in his hands, and the line comes up steaming. Sixty feet. Then the sea shoulders the hull. A mass under the keel displaces the ocean instead of swimming through it, and the whole ship lifts once, a slow rise, a pause, a set-down that finds the same glass waiting.*
>
> *It keeps going east. The lead still finds bottom, closer than the last cast. [[thunk|Thunk]] has both palms on the breech of the nearest gun.*
>
> *How do you cross it?*
