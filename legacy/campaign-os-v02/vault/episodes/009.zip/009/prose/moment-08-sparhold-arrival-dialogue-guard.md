---
type: dialogue
status: pending
publish: false
aliases: []
summary: "The cropped-hair wants a name, a business, and a bond before she writes a word."
goal: "No one enters without a name, a business, and a bond."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, intrigue]
parent: "[[moment-08-sparhold-arrival]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 07687a31-4dea-41e6-88c9-4b493eb006d7
---

> [!dialogue]
> *The cropped-hair*: Name. Business. Bond on the weapons before I write a word. Who speaks for this hull?
