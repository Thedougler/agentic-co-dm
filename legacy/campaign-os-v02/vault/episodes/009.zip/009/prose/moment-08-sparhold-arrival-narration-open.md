---
type: narration
status: pending
publish: false
aliases: []
summary: "The boom opens on a dock of old women and boys. A cropped-hair writes while the last link comes back up."
goal: "Sparhold's working-age are gone; children and old women hold the dock."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, intrigue]
mode: establish
parent: "[[moment-08-sparhold-arrival]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 15e75b5f-7fa9-4ec0-9a24-137e81fc9762
---

> [!narration]
> *The boom chain goes slack until the mouth is a gap a single hull can take. Fitted stone stands close on either side of [[sparhold|Sparhold]]'s mouth, banded black where old fires climbed it, and the water inside smells of creosote and fish guts.*
>
> *On the lowest dock an old woman lashes a board to a post, and a boy with a split nail has the next board. No fighting-age among them. A crowd three deep faces a slate, backs to the harbour.*
>
> *A harbour boat comes across on six oars, green and bone-white. The cropped-hair does not hail until the hook is up. The hook sets on the rail beside [[perrin-black-jaw|Perrin]] without touching him. Her eyes go up over [[crissdalynn-khinriss|Crissdalynn]]'s wings, down the fresh paint, and back to the page. Behind the hull the chain comes back out of the water.*
>
> *What do you tell her?*
