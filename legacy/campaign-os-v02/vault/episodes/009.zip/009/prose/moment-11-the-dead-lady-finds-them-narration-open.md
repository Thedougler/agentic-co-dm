---
type: narration
status: pending
publish: false
aliases: []
summary: "A dusk pulse through the keel. A lantern finds thickness under the hull. A carved woman rises, and hands work her lines without looking up."
goal: "A carved woman is under the hull, and living hands work her."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, horror]
mode: establish
parent: "[[moment-11-the-dead-lady-finds-them]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 916b06af-0a26-46c0-9cb4-1b4258a62c8c
---

> [!narration]
> *At a quarter past seven the sun goes into the western water and the sea turns the colour of a coin left in a pocket. Then the deck hums. A slow pulse comes up through the planking, one beat, a gap, another, into the teeth. Forty feet aft the mugs [[thunk|Thunk]] hangs over the gun deck ring.*
>
> *[[old-faas|Old Faas]] drops the ship's only lantern on a line. The light finds a thickness the current will not move, red, running parallel to the keel. Twenty feet off the port bow a carved woman comes out of the water, painted eyes pointed at this deck, mouth open. Figures work her lines and do not look up. Her canvas is full, and there is still no sound of a bow wave, only the pulse in the teeth.*
>
> *What do you do?*
