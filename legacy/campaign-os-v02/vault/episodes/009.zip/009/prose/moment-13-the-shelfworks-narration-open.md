---
type: narration
status: pending
publish: false
aliases: []
summary: "Empty Goldrush water over the western shelf, slack buoys and bare hooks, a warm bucket, and a shimmer that is climbing."
goal: "The Goldrush water is empty; heat is climbing the western shelf."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, exploration, horror]
mode: establish
parent: "[[moment-13-the-shelfworks]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 10a7e256-b456-457f-866b-3db442722251
---

> [!narration]
> *The water changes colour in one stroke of the hull. Living blue-green ends along a line a person could walk. Beyond it the *[[uncertainty|Uncertainty]]* sits over the western shelf of [[the-drowned-maw|The Drowned Maw]] in a flat that has no current left in it, sixty feet of water so clear the light goes all the way down and comes back, and the air has no salt-bite, only heat.*
>
> *Marker buoys stitch the empty water, their dive lines slack. A five-fingered hook hangs empty off a ruin-edge, uncorroded. The bucket [[old-faas|Old Faas]] hauls up comes aboard warm as bathwater and smells of dead fish and hot iron. He holds the pail away from his shirt. The shimmer where the warm water starts is climbing.*
>
> *What do you tell him?*
