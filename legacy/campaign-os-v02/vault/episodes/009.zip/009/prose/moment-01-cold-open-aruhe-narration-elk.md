---
type: narration
status: pending
publish: false
aliases: []
summary: "An elk unfolds on the reef shelf and turns toward the long-hair and the branded one in the surf."
goal: "The reef predator is taking the long-hair and the branded one."
created: "2026-08-14"
updated: "2026-08-14"
tags: [survival, maritime, horror]
mode: continue
parent: "[[sequence-01-cold-open-aruhe]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: a1b2c3d4-e5f6-4789-a012-3456789abc03
---

> [!narration]
> *The ram screams behind, pacing the tideline on a broken hitch-step, then turning back as if the water itself has a wall it will not cross.*
>
> *Thigh-deep, an elk unfolds from behind a rock ledge, the rack wider than a man can reach, legs hitching at angles that do not track with the joints. It steps onto the broken coral and stands in the only gap between surf and the deeper green. The long-hair's arms slap instead of cutting; the branded one keeps the marked shoulder out of the chop. The elk's head turns toward the splashing, already decided.*
