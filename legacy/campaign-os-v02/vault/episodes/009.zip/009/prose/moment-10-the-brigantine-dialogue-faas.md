---
type: dialogue
status: pending
publish: false
aliases: []
summary: "Old Faas asks if anyone put coin in the basin before he writes the sighting."
goal: "He will not log the sighting until someone admits the basin tribute."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, horror]
parent: "[[moment-10-the-brigantine]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 929b049c-0bb2-48de-99d8-7c741ef2648d
---

> [!dialogue]
> *[[old-faas|Old Faas]]*: Did anyone put coin in the basin. I am writing the sighting. What do you want done.
