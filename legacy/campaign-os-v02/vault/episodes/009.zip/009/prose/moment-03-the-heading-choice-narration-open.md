---
type: narration
status: pending
publish: false
aliases: []
summary: "Geoffrey pins five equal ink-lines on a raw pine table and will not rest a hand on any of them."
goal: "Five equal destinations; the crew must name one."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, travel]
mode: establish
parent: "[[moment-03-the-heading-choice]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: c3d4e5f6-a7b8-4901-c234-5678901cde02
---

> [!narration]
> *The new chart table still smells of the loft it came from, raw pine under a wipe of linseed, and [[geoffrey-draves|Geoffrey]] pins its four corners, a pencil stub behind one ear. Wind taps the panes.*
>
> *He blows the rose once, then draws. West leaves the rose in fresh ink, and south takes the same weight, and the rest match it. A mark for the [[high-eyrie|High Eyrie]]. [[sparhold|Sparhold]]. [[kalowe|Kalowe]] under a lane of small crosses. [[the-drowned-maw|the Maw]], the rose drawn twice. Farther east, [[fathomrush|Fathomrush]], two dark bars and a gap.*
>
> *He leaves the dividers a finger's width from each line and does not rest a hand on any of them. The five lines wait in the same attitude as the wind.*
>
> *Which bearing do you give the helm?*
