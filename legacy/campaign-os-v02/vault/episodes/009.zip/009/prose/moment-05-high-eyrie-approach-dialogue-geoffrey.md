---
type: dialogue
status: pending
publish: false
aliases: []
summary: "Geoffrey wants a name on the rope and a name on the wheel before the white water."
goal: "Someone must take the rope and the wheel before white water."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, exploration]
parent: "[[moment-05-high-eyrie-approach]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: d52fbc9f-5f05-4898-81dd-40132ad84f0d
---

> [!dialogue]
> *[[geoffrey-draves|Geoffrey Draves]]*: I need a name on the rope and a name on the wheel before we take the white water. Who climbs, and who stays.
