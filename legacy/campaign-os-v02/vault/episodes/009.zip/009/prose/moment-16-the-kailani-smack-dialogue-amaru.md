---
type: dialogue
status: pending
publish: false
aliases: []
summary: "Petro Amaru wants the fire in their words and anything off his rows priced before he writes."
goal: "He prices anything off his rows before he writes."
created: "2026-08-14"
updated: "2026-08-14"
tags: [maritime, intrigue]
parent: "[[moment-16-the-kailani-smack]]"
owner_skill: ".claude/skills/writing-player-prose/SKILL.md"
uid: 05063180-5fac-4393-8928-55aaeb8efec2
---

> [!dialogue]
> *[[petro-amaru|Petro Amaru]]*: Whose hull. I want the fire on my page in your words, and anything you lifted off my rows priced before I write it. What do I write.
