---
type: passage
status: pending
publish: false
aliases: ["Three Days West", "West Crossing"]
created: "2026-08-11"
updated: "2026-08-13"
tags: [maritime, travel]
summary: "Three days west against the Scatter Current to the High Eyrie, keeping to readable shelf water while portable shipboard pressures surface at the crew's pace."
method: ship
distance: Far
duration: "three days"
from_moment: "[[fork-01-the-heading-choice]]"
destination: "The High Eyrie"
reconverges_at:
beats:
  - "[[beat-03-waveservant-wreckage]]"
  - "[[beat-06-strange-pennant]]"
  - "[[beat-08-the-chemical-story]]"
  - "[[beat-09-the-depot]]"
  - "[[beat-10-the-squall]]"
conditions: "Scatter Current running east through the Central Strait, costing half a knot against a westbound hull"
passage_number: 2
parent_run_guide: "[[e09-run-guide|Session 09 Run Guide]]"
session_number: 9
npcs: ["[[old-faas|Old Faas]]", "[[sem-holst|Sem Holst]]", "[[geoffrey-draves|Geoffrey Draves]]", "[[thunk|Thunk]]"]
locations: ["[[calveno|Calveno]]", "[[central-strait|Central Strait]]", "[[high-eyrie|The High Eyrie]]"]
campaigns: [Shattered Sea]
owner_skill: "vault/episodes/.claude/skills/draft-passage/SKILL.md"
---

# Session 09, Passage 2: Three Days West

## Departure Cost

The Scatter Current runs east through the [[central-strait|Central Strait]] and costs any westbound hull half a knot. [[old-faas|Old Faas]] trades speed for the shallow water he can read, running a line north of the [[central-strait-crossing|Blue Lane]], close enough to the shelf that the keel runs over pale green water and the ribs of old wrecks show at eighty feet.

## The Crossing

[[calveno|Calveno]] drops under the horizon before noon and the sea takes the last smudge of chimney smoke with it. Three days of open water lie between the crew and the [[high-eyrie|High Eyrie]], with nothing out here hunting them, just everything already loaded aboard ripening at its own speed. Flat water runs the full crossing, giving every thread below its full course. The third day is where the current collects its fee.

## Roles

Navigator, Lookout, Quartermaster, Bosun, and Captain: five stations for the full three days. The line north of the Lane keeps the shelf under the keel the whole way. Any post left uncalled takes its failure side unanswered, and the crew settle among themselves who takes which.

![[ship-operations#Stations Underway]]

## Group Check

> [!check] Group Survival — Three Days West Against the Current
> **Critical Failure (5-25):** the line north of the Lane puts her over the shelf on a falling tide, and warping off the sandbar costs a full day; they raise the Eyrie on the fourth morning with the weather already turned.
>
> **Failure (26-49):** a cask spoils and the rigging shows its age; they arrive on time, and the first sail order of the next trouble comes at disadvantage.
>
> **Success (50-74):** the leg runs true. Both free days stay free, and every thread below gets its full run.
>
> **Critical Success (75+):** a day shaved. They raise the Eyrie Light on the third morning ahead of the rain, with stores enough to spare and every hand rested.

## Beat Menu

| #   | Beat file                    | Type     | Trigger                                                                  |
| --- | ---------------------------- | -------- | ------------------------------------------------------------------------ |
| 3   | [[beat-03-waveservant-wreckage\|Waveservant Wreckage]] | optional | Open horizon in daylight, a stripped hull drifts into view          |
| 6   | [[beat-06-strange-pennant]]      | optional | Another sail crosses the heading under an unknown pennant           |
| 8   | [[beat-08-the-chemical-story]]   | optional | The crew checks or restocks the reagent stores after two days at sea |
| 9   | [[beat-09-the-depot]]            | optional | Orange hull broad on the starboard bow, unmistakable at a mile       |
| 10  | [[beat-10-the-squall]]           | optional | Northwest horizon darkens mid-crossing, the chop turning quartering  |

## Landmark

The shallow water over the continental shelf, pale green and readable, where the ribs of an old wreck show at eighty feet and the grain of the bottom tells [[old-faas|Old Faas]] more than the chart does.

## Toll

Half a knot of current against the hull the whole way west. The crossing charges it in the third day, not in stores or blood.

## Arrival Changed

Three days aboard one hull, nothing to do but reckon with what's already loaded. Whatever they chose to open or leave shut settles by the time the [[high-eyrie|High Eyrie]]'s black vertical mark breaks two hundred miles of flat horizon.

## Next

[[high-eyrie|The High Eyrie]], when the crossing ends.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[high-eyrie|The High Eyrie]]
