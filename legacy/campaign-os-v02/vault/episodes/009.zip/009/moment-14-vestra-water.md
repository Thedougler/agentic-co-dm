---
type: moment
status: pending
publish: false
aliases: []
created: "2026-08-10"
updated: "2026-08-14"
tags: [exploration, mystery]
summary: "A heat line stills the water under the hull; a mass lifts the ship once and runs east toward the Maw drop-off."
tier: supporting
edit_pass: 0
parent_run_guide: "[[e09-run-guide]]"
session_number: 9
moment_number: 14
world_date: "1495 DR"
reached_from: ["[[moment-13-the-shelfworks]]"]
fork_depth: 1
engagement: required
terminal: true
npcs: ["[[old-faas|Old Faas]]", "[[thunk|Thunk]]", "[[auralis|Auralis]]"]
monsters: []
statblocks: []
locations: ["[[the-drowned-maw|The Drowned Maw]]", "[[shelfworks|The Shelfworks]]"]
encounter: ""
campaigns: [Shattered Sea]
owner_skill: ".claude/skills/session-prep/references/moment.md"
uid: 155d8b06-20b5-4ae7-81c6-50672ebd01df
---

# Session 09, Moment 14: Vestra Water

- [ ] Ran

```meta-bind-button
label: ▶ Run Moment
style: primary
action:
  type: command
  command: obsidian-shellcommands:shell-command-runscene00
```

![[moment-14-vestra-water-narration-open]]

![[moment-14-vestra-water-dialogue-faas-thunk]]

## What Happens

The mass under the hull is [[auralis|Auralis]], the [[antheri|Antheri]] machine-mind sealing the [[elemental-plane-of-water|Elemental Plane of Water]]'s rift. It has sat here since the *[[vestra|Vestra]]* came apart. It has never said what pact bought [[perrin-black-jaw|Perrin]] out. It wants Perrin grown large enough to hold the boundary himself. It moves by pressure, warms the water, and kills the swell. Its one word, *Grow*, lands without sound. It steers by the drum, following [[the-snap|The Snap]]'s beat since [[calveno|Calveno]].

The [[pearl-of-souls|Pearl of Souls]] in the *[[red-lady|Red Lady]]*'s hull pries the fissure wider than Auralis can close. The [[shelfworks|Shelfworks]] rush has stripped the containment works since 1488. Built to sit still at the trench bottom, it now works at sixty feet. It returns under this hull inside the hour, closer and hotter each pass. Nobody aboard has taken a blow yet. The heat is courtesy. The *Vestra* received the same.

## What they want

**The ask:** direct. [[old-faas|Old Faas]] wants [[perrin-black-jaw|Perrin]] to take this water as the place the *[[vestra|Vestra]]* went down.

## Checks

> [!check] Survival (DC 14, at the rail, lead line, or tiller; second lead cast grants advantage) — Reading the Warm Lane
> **Success:** even-temperature lane, two hundred feet wide, running east; source moving under it, not a vent; far end past the drop-off.
>
> **Failure:** misread as a vent field; next pass arrives with no warning.

> [!mechanic] Past the shelf edge
> The shelf sits at a hundred and fifty feet and ends a quarter mile east. Past it the trench has no bottom any sounding line has found, and the ship carries a hundred fathoms of rope, which is not enough. Nothing anchors over the Maw because there is nothing to anchor to. The compass has been lying since two days out and does not recover until the far side, so the crossing runs on sun angle by day and star fixes after dark. Flat, current-less water makes the ship easy to handle and impossible to hold in place.

## Next

The ship sits on blood-warm glass over the shelf. A quarter mile east the shelf falls away and the lead finds nothing. Hold here and the heat comes back inside the hour, closer and hotter. Run east and the sounding line means nothing; the mass is already ahead. Come about for the green water astern and the Maw does not follow; the water cools inside the hour.

## Connections

- [[e09-run-guide|parent Run Guide]]
- [[old-faas|Old Faas]]
- [[thunk|Thunk]]
- [[auralis|Auralis]]
- [[the-drowned-maw|The Drowned Maw]]
